package com.bjsxt.passport.controller;

import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.passport.service.PassportService;
import com.bjsxt.pojo.TbUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

/**
 * 前台 用户登录与注册 控制器
 */
@RestController
public class PassportController {
    @Autowired
    private PassportService passportService;

    /**
     * 退出登录。就是销毁HttpSession会话对象。
     * @return
     */
    @PostMapping("/user/logout")
    public BaizhanResult logout(HttpSession session){
        session.invalidate();
        return BaizhanResult.ok();
    }

    /**
     * 登录
     * @param username 身份 principal。标记一个数据的唯一。
     *                 用户名，手机号，电子邮箱
     * @param password 凭证 credential。 标记一个数据的安全。
     *                 密码
     * @return
     */
    @PostMapping("/user/userLogin")
    public BaizhanResult login(String username, String password, HttpSession session){
        BaizhanResult result = passportService.login(username, password);
        session.setAttribute("loginUser", result.getData());
        return result;
    }

    /**
     * 用户注册
     * @return
     */
    @PostMapping("/user/userRegister")
    private BaizhanResult register(TbUser user){
        try {
            return passportService.register(user);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 检查要注册的用户数据是否唯一
     * @param value 要检查的数据值
     * @param flag 数据的种类。 1-用户名；2-手机号；3-电子邮箱
     * @return
     */
    @GetMapping("/user/checkUserInfo/{value}/{flag}")
    public BaizhanResult checkRegisterUserInfo(@PathVariable("value") String value,
                                               @PathVariable("flag") int flag){
        return passportService.checkRegisterUserInfo(value, flag);
    }
}
