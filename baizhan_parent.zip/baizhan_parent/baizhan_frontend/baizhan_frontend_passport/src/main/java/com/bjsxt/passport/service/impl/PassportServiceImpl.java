package com.bjsxt.passport.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.mapper.TbUserMapper;
import com.bjsxt.passport.service.PassportService;
import com.bjsxt.pojo.TbUser;
import com.bjsxt.utils.IDUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import java.util.Date;

/**
 * 前台 用户登录与注册 服务实现
 */
@Service
public class PassportServiceImpl implements PassportService {
    @Autowired
    private TbUserMapper userMapper;

    /**
     * 登录
     *  身份作为用户名+凭证查询；身份作为手机号+凭证查询；身份作为电子邮箱+凭证查询
     * @param principal 身份
     * @param credential 凭证
     * @return
     */
    @Override
    public BaizhanResult login(String principal, String credential) {
        QueryWrapper<TbUser> queryWrapper =
                new QueryWrapper<>();
        queryWrapper.eq("username", principal)
                .or().eq("phone", principal)
                .or().eq("email", principal);
        TbUser user = userMapper.selectOne(queryWrapper);
        // 登录传递的凭证做加密处理
        String digest = DigestUtils.md5DigestAsHex(credential.getBytes());
        if(digest.equals(user.getPassword())){
            // 登录成功
            // 返回给客户端的数据，记录在服务器内存的数据，记录在缓存的数据
            // 不准包含敏感数据。如：密码，钱
            user.setPassword(null);
            return BaizhanResult.ok(user);
        }else{
            // 登录失败
            return BaizhanResult.error("用户名或密码错误");
        }
    }

    /**
     * 注册，注册用户的密码需要加密处理
     * @param user
     * @return
     */
    @Override
    @Transactional
    public BaizhanResult register(TbUser user) {
        try {
            // 密码加密。
            String digestPassword =
                    DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
            user.setPassword(digestPassword);

            // 数据完整性处理
            user.setId(IDUtils.genItemId());
            Date now = new Date();
            user.setCreated(now);
            user.setUpdated(now);

            // 保存用户数据到数据库
            int rows = userMapper.insert(user);
            if (rows != 1) {
                throw new DaoException("用户注册错误");
            }

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("用户注册时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 检查用户注册数据是否唯一
     * @param value
     * @param flag
     * @return
     */
    @Override
    public BaizhanResult checkRegisterUserInfo(String value, int flag) {
        // 判断要检查的数据种类是什么
        if(1 == flag){
            // 用户名是否唯一
            QueryWrapper<TbUser> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("username", value)
                    .or().eq("phone", value);
            int rows = userMapper.selectCount(queryWrapper);
            if(rows > 0){
                // 用户名重复，不可用
                return BaizhanResult.error("用户名重复，请重新输入");
            }else{
                // 用户名唯一，可用
                return BaizhanResult.ok();
            }
        }else if(2 == flag){
            // 手机号是否唯一
            QueryWrapper<TbUser> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("phone", value)
                    .or().eq("username", value);
            int rows = userMapper.selectCount(queryWrapper);
            if(rows > 0){
                // 手机号重复，不可用
                return BaizhanResult.error("手机号重复，请重新输入");
            }else{
                // 手机号唯一，可用
                return BaizhanResult.ok();
            }
        }else if(3 == flag){
            // 电子邮箱是否唯一
            QueryWrapper<TbUser> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("email", value);
            int rows = userMapper.selectCount(queryWrapper);
            if(rows > 0){
                // 电子邮箱重复，不可用
                return BaizhanResult.error("电子邮箱重复，请重新输入");
            }else{
                // 电子邮箱号唯一，可用
                return BaizhanResult.ok();
            }
        }else{
            // 错误参数
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }
}
