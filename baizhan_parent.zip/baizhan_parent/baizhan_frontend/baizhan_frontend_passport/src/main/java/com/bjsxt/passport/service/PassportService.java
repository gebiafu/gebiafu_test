package com.bjsxt.passport.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbUser;

/**
 * 前台 用户登录与注册 服务接口
 */
public interface PassportService {
    /**
     * 登录
     * @param principal 身份
     * @param credential 凭证
     * @return
     */
    BaizhanResult login(String principal, String credential);

    /**
     * 注册
     * @param user
     * @return
     */
    BaizhanResult register(TbUser user);

    /**
     * 校验用户数据是否唯一
     * @param value
     * @param flag
     * @return
     */
    BaizhanResult checkRegisterUserInfo(String value, int flag);
}
