package com.bjsxt.trade.service.impl;

import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.dao.RedisDao;
import com.bjsxt.feign.FrontendDetailsFeignClient;
import com.bjsxt.mapper.TbOrderItemMapper;
import com.bjsxt.mapper.TbOrderMapper;
import com.bjsxt.mapper.TbOrderShippingMapper;
import com.bjsxt.message.pojo.cart.SyncCartMessage;
import com.bjsxt.message.pojo.notice.OrderNoticeMessage;
import com.bjsxt.message.pojo.order.CreateOrderMessage;
import com.bjsxt.message.sender.MessageSender;
import com.bjsxt.pojo.*;
import com.bjsxt.trade.service.TradeService;
import com.bjsxt.utils.IDUtils;
import com.codingapi.txlcn.tc.annotation.LcnTransaction;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 前台 订单 服务实现
 */
@Service
public class TradeServiceImpl implements TradeService {
    // Jackson中的Object映射类型。
    private final ObjectMapper objectMapper = new ObjectMapper();
    @Value("${baizhan.details.itemKeyPrefix}")
    private String itemKeyPrefix;
    @Value("${baizhan.detailsLock.itemKeyPrefix}")
    private String lockItemKeyPrefix;
    @Autowired
    private RedisDao redisDao;
    @Autowired
    private MessageSender messageSender;
    @Value("${baizhan.trade.create.exchange}")
    private String createExchange;
    @Value("${baizhan.trade.create.routingKey}")
    private String createRoutingKey;
    @Value("${baizhan.cart.sync.exchange}")
    private String cartExchange;
    @Value("${baizhan.cart.sync.routingKey}")
    private String cartRoutingKey;
    @Value("${baizhan.notice.mailAndSms.exchange}")
    private String mailAndSmsExchange;
    @Value("${baizhan.notice.mailAndSms.routingKey}")
    private String mailAndSmsRoutingKey;
    @Autowired
    private TbOrderMapper orderMapper;
    @Autowired
    private TbOrderShippingMapper orderShippingMapper;
    @Autowired
    private TbOrderItemMapper orderItemMapper;

    /**
     * 新增订单，订单物流，订单项到数据库
     * @param params
     * @return
     */
    @Override
    @Transactional
    @LcnTransaction
    public BaizhanResult insertOrder2DB(Map<String, Object> params) {
        TbOrder order =
                map2Object((LinkedHashMap) params.get("order"), TbOrder.class);
        TbOrderShipping orderShipping =
                map2Object((LinkedHashMap) params.get("orderShipping"), TbOrderShipping.class);
        List<TbOrderItem> tbOrderItems =
                map2List((List<LinkedHashMap>) params.get("orderItems"), TbOrderItem.class);

        try {
            // 新增订单
            int rows = orderMapper.insert(order);
            if (rows != 1) {
                throw new DaoException("创建订单错误");
            }
            rows = orderShippingMapper.insert(orderShipping);
            if (rows != 1) {
                throw new DaoException("创建订单物流错误");
            }
            rows = 0;
            for (TbOrderItem orderItem : tbOrderItems) {
                rows += orderItemMapper.insert(orderItem);
            }
            if (rows != tbOrderItems.size()) {
                throw new DaoException("创建订单项错误");
            }

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("创建订单时，数据库访问错误:" + e.getMessage());
        }
    }

    private <T> List<T> map2List(List list, Class<T> t){
        try {
            // 把List集合 -> JSON格式字符串
            String temp = objectMapper.writeValueAsString(list);
            // 创建需要的具体集合类型和泛型
            JavaType type = objectMapper.getTypeFactory()
                    .constructParametricType(List.class, t);
            // 把JSON字符串转换成Java对象
            return objectMapper.readValue(temp, type);
        }catch (Exception e){
            return null;
        }
    }

    private <T> T map2Object(LinkedHashMap map, Class<T> t){
        try {
            // 把Map对象-> JSON格式字符串
            String temp = objectMapper.writeValueAsString(map);
            // 把JSON字符串，转换成需要的Java类型对象
            return objectMapper.readValue(temp, t);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 创建订单
     *  流程：
     *   1. 处理请求参数，解析orderItem字符串
     *   2. 所有的订单相关数据完整性处理。
     *   3. 再次检查商品库存是否充足。如果库存充足，则锁定库存（库存-购买数）。
     *      本操作基于Redis实现。
     *      使用Redis锁定库存的优点： 性能高，可以通过分布式锁保证准确性。
     *      使用Redis锁定库存的缺点： 最终数据有延迟，锁redis中的库存，创建订单的时候，要修改数据库中的商品库存量。
     *   4. 创建订单。
     *     4.1 数据库操作。新增订单、订单项、订单物流； 修改商品库存
     *         4.1.1 当前方法直接访问数据库，新增数据，修改数据。 特点是慢，数据原子性更好。
     *         4.1.2 使用消息异步处理。发送消息到MQ，消费者消费消息，新增、修改数据。特点是快，数据有延迟。
     *   5. 清理购物车中已购买的商品数据
     *     使用消息中间件实现购物车的处理。发送消息到MQ。消费者处理，访问购物车，删除已购买商品
     *   6. 发送邮件给购买者，做创建订单的提醒。可以配合短信一起通知
     *     使用消息中间件实现
     *   7. 返回创建订单的结果
     *
     * @param order 订单对象
     * @param orderShipping 订单物流对象
     * @param orderItem 订单项JSON格式字符串
     * @return
     */
    @Override
    public BaizhanResult createOrder(TbOrder order, TbOrderShipping orderShipping,
                                     String orderItem, TbUser tbUser) {
        // 转换请求参数
        List<TbOrderItem> orderItems = json2List(orderItem);
        if(orderItems.size() == 0){
            // 参数处理错误，后续代码不再运行
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
        // 数据完整性处理
        Long orderId = IDUtils.genItemId();
        Date now = new Date();
        // 订单数据
        order.setOrderId(orderId);
        order.setCreateTime(now);
        order.setUpdateTime(now);
        order.setStatus(1); // 未付款
        order.setUserId(tbUser.getId()); // 购买者主键
        order.setBuyerNick(tbUser.getUsername()) ; // 购买者昵称
        order.setBuyerRate(0) ; // 是否已评价

        // 订单物流
        orderShipping.setOrderId(orderId);
        orderShipping.setCreated(now);
        orderShipping.setUpdated(now);

        // 用于同步购物车数据的集合
        List<Long> syncCartItemIds = new ArrayList<>();
        // 订单项
        for(TbOrderItem item : orderItems){
            item.setId(IDUtils.genItemId());
            item.setOrderId(orderId);
            syncCartItemIds.add(item.getItemId());
        }

        // 锁定库存。锁定的同时，就是检查库存量是否足够。如果有任何商品库存不足，都要取消锁定。
        boolean isLock = lockNum(orderItems, 0);
        if(!isLock){
            // 锁定失败，创建订单失败
            return BaizhanResult.error("您购买的商品库存量不足，请选择其他商品");
        }
        // 锁定成功，执行后续流程。创建订单、修改数据库中商品库存等。基于MQ实现处理。
        // 创建消息对象
        CreateOrderMessage message = new CreateOrderMessage();
        message.setOrder(order);
        message.setOrderShipping(orderShipping);
        message.setOrderItems(orderItems);
        messageSender.sendMessage(createExchange, createRoutingKey, message);

        // 发送同步购物车的消息
        // 创建同步购物车的消息对象
        SyncCartMessage cartMessage = new SyncCartMessage();
        cartMessage.setUserId(tbUser.getId());
        cartMessage.setItemIds(syncCartItemIds);
        messageSender.sendMessage(cartExchange, cartRoutingKey, cartMessage);

        // 发送通知消息
        OrderNoticeMessage noticeMessage = new OrderNoticeMessage();
        noticeMessage.setName(tbUser.getUsername());
        noticeMessage.setEmail(tbUser.getEmail());
        noticeMessage.setPhone(tbUser.getPhone());
        noticeMessage.setOrderId(order.getOrderId());
        messageSender.sendMessage(mailAndSmsExchange, mailAndSmsRoutingKey, noticeMessage);

        return BaizhanResult.ok(order.getOrderId());
    }

    @Autowired
    private FrontendDetailsFeignClient frontendDetailsFeignClient;

    /**
     * 处理库存锁定
     * @param orderItems
     * @param index 从下标多少开始锁定库存
     * @return
     */
    private boolean lockNum(List<TbOrderItem> orderItems, int index){
        try {
            for (; index < orderItems.size(); ) {
                TbOrderItem orderItem = orderItems.get(index++);
                // 获取锁标记
                String lockKey = lockItemKeyPrefix + orderItem.getItemId();
                boolean isLock = false;
                isLock = redisDao.setNx(lockKey, "", 2L, TimeUnit.SECONDS);
                if (!isLock) {
                    // 自旋处理
                    return lockNum(orderItems, index - 1);
                }
                // 有锁，查询商品的库存
                TbItem item = redisDao.get(itemKeyPrefix + orderItem.getItemId());
                if (item == null) {
                    // 缓存中没有商品数据。远程调用服务查询商品
                    BaizhanResult result =
                            frontendDetailsFeignClient.getItemById(orderItem.getItemId());
                    if (result.getStatus() != 200) {
                        throw new RuntimeException("库存不足");
                    }
                    item = map2Item((LinkedHashMap) result.getData());
                }
                // 判断库存量是否足够
                if (item.getNum() >= orderItem.getNum()) {
                    // 库存量足够, 锁定库存
                    item.setNum(item.getNum() - orderItem.getNum());
                    // 保存到Redis
                    redisDao.set(itemKeyPrefix + orderItem.getItemId(), item, 7L, TimeUnit.DAYS);
                    redisDao.delete(lockKey);
                } else {
                    redisDao.delete(lockKey);
                    throw new RuntimeException("库存不足");
                }
            }
            return true;
        }catch (RuntimeException e){
            // 库存不足
            return reverseNum(orderItems, 0, index);
        }
    }

    private TbItem map2Item(Map<String, Object> map){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        TbItem item = new TbItem();
        item.setId((Long) map.get("id"));
        try {
            item.setUpdated(sdf.parse(map.get("updated").toString()));
        } catch (ParseException e) {
            item.setUpdated(null);
            e.printStackTrace();
        }
        try {
            item.setCreated(sdf.parse(map.get("created").toString()));
        } catch (ParseException e) {
            item.setCreated(null);
            e.printStackTrace();
        }
        item.setNum((int) map.get("num"));
        item.setStatus((Integer) map.get("status"));
        item.setBarcode(map.get("barcode") == null ? "" : map.get("barcode").toString());
        item.setCid((Long) map.get("cid"));
        item.setImage(map.get("image") == null ? "" : map.get("image").toString());
        item.setPrice((Long) map.get("price"));
        item.setSellPoint(map.get("sellPoint") == null ? "" : map.get("sellPoint").toString());
        item.setTitle(map.get("title") == null ? "" : map.get("title").toString());
        return item;
    }

    /**
     * 恢复库存
     * @param orderItems
     * @param begin
     * @param index
     * @return
     */
    private boolean reverseNum(List<TbOrderItem> orderItems, int begin, int index){
        for(int i = begin ; i < index; i++){ // 加锁
            // 获取锁
            boolean isLock = redisDao.setNx(lockItemKeyPrefix+orderItems.get(i).getItemId(),
                    "", 2L, TimeUnit.SECONDS);
            if(!isLock){
                return reverseNum(orderItems, i, index);
            }
            TbItem item = redisDao.get(itemKeyPrefix + orderItems.get(i).getItemId());
            item.setNum( item.getNum() + orderItems.get(i).getNum() );
            redisDao.set(itemKeyPrefix + orderItems.get(i).getItemId(), item);
            // 释放锁
            redisDao.delete(lockItemKeyPrefix+orderItems.get(i).getItemId());
        }
        return false;
    }

    /**
     * 把JSON格式的字符串，转换成需要的List集合对象
     * @return
     */
    private List<TbOrderItem> json2List(String json){
        // 创建一个需要转换的具体Java类型
        JavaType type =
                objectMapper.getTypeFactory()
                        .constructParametricType(List.class, TbOrderItem.class);
        // 定义要返回的集合引用
        List<TbOrderItem> resultList = null;
        try{
            resultList = objectMapper.readValue(json, type);
        }catch (Exception e){
            e.printStackTrace(); // 有数据转换异常，提供一个空的集合
            resultList = new ArrayList<>();
        }

        return resultList;
    }
}
