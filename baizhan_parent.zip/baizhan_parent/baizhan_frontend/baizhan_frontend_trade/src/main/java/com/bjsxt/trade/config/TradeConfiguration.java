package com.bjsxt.trade.config;

import com.bjsxt.config.AbstractRedisConfiguration;
import com.bjsxt.dao.RedisDao;
import com.bjsxt.message.sender.MessageSender;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

@Configuration
public class TradeConfiguration extends AbstractRedisConfiguration {
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory){
        return super.redisTemplate(factory);
    }

    @Bean
    public RedisDao redisDao(RedisTemplate<String, Object> template){
        return super.redisDao(template);
    }

    @Bean
    public MessageSender messageSender(AmqpTemplate amqpTemplate){
        MessageSender messageSender = new MessageSender();
        messageSender.setAmqpTemplate(amqpTemplate);
        return messageSender;
    }
}
