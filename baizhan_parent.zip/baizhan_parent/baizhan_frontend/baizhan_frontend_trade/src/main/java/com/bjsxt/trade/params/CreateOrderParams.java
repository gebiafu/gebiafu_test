package com.bjsxt.trade.params;

import com.bjsxt.pojo.TbOrderItem;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 创建订单使用的请求参数映射类型。
 * 主要处理参数中的
 *  orderItem[0].id=xxx&orderItem[0].title=xxx&orderItem[0].price=xxx&
 *  orderItem[1].id=xxx&orderItem[1].title=xxx&orderItem[1].price=xxx&
 *  orderItem[2].id=xxx&orderItem[2].title=xxx&orderItem[2].price=xxx
 */
@Data
public class CreateOrderParams implements Serializable {
    private List<TbOrderItem> orderItem;
}
