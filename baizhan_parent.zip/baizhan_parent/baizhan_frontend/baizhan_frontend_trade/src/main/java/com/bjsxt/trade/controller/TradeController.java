package com.bjsxt.trade.controller;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbOrder;
import com.bjsxt.pojo.TbOrderItem;
import com.bjsxt.pojo.TbOrderShipping;
import com.bjsxt.pojo.TbUser;
import com.bjsxt.trade.params.CreateOrderParams;
import com.bjsxt.trade.service.TradeService;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * 前台 订单 控制器
 */
@RestController
public class TradeController {
    @Autowired
    private TradeService tradeService;

    /**
     * 新增订单，订单物流，订单项
     * @param params 要新增的数据集合。请求体传递
     *               key            value
     *               order          TbOrder类型对象，要新增的订单
     *               orderShipping  TbOrderShipping类型对象，订单物流
     *               orderItems     List<TbOrderItem>类型的集合，订单项集合
     */
    @PostMapping("/order/insertOrder2DB")
    public BaizhanResult insertOrder2DB(@RequestBody Map<String, Object> params){
        // 调用服务逻辑，新增数据到数据库
        return tradeService.insertOrder2DB(params);
    }

    /**
     * 创建订单
     * @param order 收集订单数据，如：支付方式，支付金额
     * @param orderShipping 收集订单物流数据，如：收件人姓名、电话等。
     * @param orderItem 收集订单中的订单项集合，如：购买的商品主键，标题，单价，数量等。
     * @return
     */
    @PostMapping("/order/insertOrder")
    public BaizhanResult createOrder(TbOrder order, TbOrderShipping orderShipping,
                                     String orderItem, HttpSession session) throws Exception {
        return tradeService.createOrder(order, orderShipping, orderItem,
                (TbUser) session.getAttribute("loginUser"));
       /* System.out.println("订单：" + order);
        System.out.println("订单物流：" + orderShipping);
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.getTypeFactory().constructParametricType(List.class, TbOrderItem.class);
        List<TbOrderItem> params = mapper.readValue(orderItem, type);
        System.out.println("订单项数量：" + params.size());
        System.out.println("订单项具体内容：" + params);*/
    }
}
