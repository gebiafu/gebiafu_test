package com.bjsxt.trade.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbOrder;
import com.bjsxt.pojo.TbOrderShipping;
import com.bjsxt.pojo.TbUser;

import java.util.Map;

/**
 * 前台 订单 服务接口
 */
public interface TradeService {
    /**
     * 新增订单相关数据到数据库
     * @param params
     * @return
     */
    BaizhanResult insertOrder2DB(Map<String, Object> params);

    /**
     * 创建订单
     * @param order 订单对象
     * @param orderShipping 订单物流对象
     * @param orderItem 订单项JSON格式字符串
     * @return
     */
    BaizhanResult createOrder(TbOrder order, TbOrderShipping orderShipping,
                              String orderItem, TbUser tbUser);
}
