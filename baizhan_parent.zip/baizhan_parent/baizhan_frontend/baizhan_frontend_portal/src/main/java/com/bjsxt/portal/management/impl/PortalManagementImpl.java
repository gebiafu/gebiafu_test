package com.bjsxt.portal.management.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.mapper.TbContentMapper;
import com.bjsxt.pojo.TbContent;
import com.bjsxt.portal.management.PortalManagement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 前台 门户 管理实现
 */
@Component
public class PortalManagementImpl implements PortalManagement {
    /**
     * 基于配置文件定义的，大广告内容分类主键
     */
    @Value("${baizhan.mysql.bigad.id}")
    private Long bigAdContentCategoryId;
    @Autowired
    private TbContentMapper contentMapper;

    @Override
    @Cacheable(cacheNames = "baizhan:portal:bigAd", key = "'getAllBigAd'")
    public List<TbContent> getAllBigAd() {
        QueryWrapper queryWrapper =
                new QueryWrapper();
        queryWrapper.eq("category_id", bigAdContentCategoryId);

        return contentMapper.selectList(queryWrapper);
    }
}
