package com.bjsxt.portal.service;

import com.bjsxt.commons.pojo.BaizhanResult;

/**
 * 前台 门户 服务接口
 */
public interface PortalService {
    /**
     * 查询轮播广告
     * @return
     */
    BaizhanResult getBigAd4Portal();
}
