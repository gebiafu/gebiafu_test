package com.bjsxt.portal.controller;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.portal.service.PortalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 前台 门户 控制器
 * 门户页面轮播图不生效解决：
 *  找前端应用源码： \src\pages\Home\Content\LunBo\index.vue
 *  修改文件中的组件定义。命名修改位首字母大写。
 *  23行  import { Swiper , SwiperSlide} from "vue-awesome-swiper";
 *  52行  components: {
 *           Swiper,
 *           SwiperSlide
 *        }
 */
@RestController
public class PortalController {
    @Autowired
    private PortalService portalService;

    /**
     * 门户主页加载查询轮播广告（大广告）
     * 没有参数。 查询的内容对应的具体分类主键，使用配置文件设定。（软编码）
     * 可以配合分布式配置中心+热刷新+bus实现动态变化。
     * @return
     */
    @GetMapping("/portal/showBigAd")
    public BaizhanResult getBigAd4Portal(){
        return portalService.getBigAd4Portal();
    }
}
