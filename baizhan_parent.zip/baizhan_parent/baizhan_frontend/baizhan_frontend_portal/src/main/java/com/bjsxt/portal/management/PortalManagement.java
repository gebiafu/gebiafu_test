package com.bjsxt.portal.management;

import com.bjsxt.pojo.TbContent;

import java.util.List;

/**
 * 前台 门户 管理接口
 */
public interface PortalManagement {
    /**
     * 查询所有的轮播广告
     * @return
     */
    List<TbContent> getAllBigAd();
}
