package com.bjsxt.portal.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.mapper.TbContentMapper;
import com.bjsxt.pojo.TbContent;
import com.bjsxt.portal.management.PortalManagement;
import com.bjsxt.portal.service.PortalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 前台 门户 服务实现
 */
@Service
@RefreshScope
public class PortalServiceImpl implements PortalService {
    @Autowired
    private PortalManagement portalManagement;
    /**
     * 查询轮播广告，就是内容数据。
     * @return
     */
    @Override
    public BaizhanResult getBigAd4Portal() {
        // 基于管理代码，查询轮播广告
        List<TbContent> list = portalManagement.getAllBigAd();

        list = sort(list);
        for(TbContent content : list){
            System.out.println(content.getId());
        }
        return BaizhanResult.ok(list);
    }

    /**
     * 打乱参数集合中元素的顺序，并只保留前8个元素返回。
     * @param source
     * @return
     */
    private List<TbContent> sort(List<TbContent> source){
        // 随机排序。方法执行结束，集合中的元素顺序随机
        Collections.shuffle(source);

        if(source.size() <= 8){
            return source;
        }

        List<TbContent> result = new ArrayList<>(8);
        for(int i = 0; i < 8; i++){
            result.add(source.get(i));
        }
        return result;
    }
}
