package com.bjsxt.config;

import com.bjsxt.dao.RedisDao;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

/**
 * 前台 商品详情展示 配置类型
 */
@Configuration
public class DetailsConfiguration extends AbstractRedisConfiguration {
    /**
     * 创建RedisTemplate对象
     */
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory){
        return super.redisTemplate(factory);
    }

    /**
     * 创建RedisDao对象
     */
    @Bean
    public RedisDao redisDao(RedisTemplate<String, Object> redisTemplate){
        return super.redisDao(redisTemplate);
    }
}
