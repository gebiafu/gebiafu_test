package com.bjsxt.details.service;

import com.bjsxt.commons.pojo.BaizhanResult;

/**
 * 前台 商品详情展示 服务接口
 */
public interface DetailsService {
    /**
     * 根据商品主键，查询商品具体规格
     * @param itemId
     * @return
     */
    BaizhanResult getItemParamItemByItemId(Long itemId);

    /**
     * 根据商品主键，查询图文介绍
     * @param itemId
     * @return
     */
    BaizhanResult getItemDescByItemId(Long itemId);

    /**
     * 根据主键查询商品
     * @param id
     * @return
     */
    BaizhanResult getItemById(Long id);
}
