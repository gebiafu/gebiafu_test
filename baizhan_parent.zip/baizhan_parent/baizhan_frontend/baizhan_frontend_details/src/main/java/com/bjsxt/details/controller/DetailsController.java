package com.bjsxt.details.controller;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.details.service.DetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 前台 商品详情展示 控制器
 */
@RestController
public class DetailsController {
    @Autowired
    private DetailsService detailsService;



    /**
     * 根据商品主键，查询商品具体规格
     * @param itemId
     * @return
     */
    @PostMapping("/item/selectTbItemParamItemByItemId")
    public BaizhanResult getItemParamItemByItemId(Long itemId){
        return detailsService.getItemParamItemByItemId(itemId);
    }

    /**
     * 根据商品主键，查询商品图文详情
     * 前端应用详情展示问题：
     *  修改前台前端代码 src\pages\Details\Evaluate\EvaluateRight\EvalRightJieShao\index.vue
     *    删除36行中的CSS高度限制。   height: 171px;
     * @param itemId
     * @return
     */
    @PostMapping("/item/selectItemDescByItemId")
    public BaizhanResult getItemDescByItemId(Long itemId){
        return detailsService.getItemDescByItemId(itemId);
    }

    /**
     * 根据主键查询商品数据
     * @return
     */
    @PostMapping("/item/selectItemInfo")
    public BaizhanResult getItemById(Long id){
        return detailsService.getItemById(id);
    }
}
