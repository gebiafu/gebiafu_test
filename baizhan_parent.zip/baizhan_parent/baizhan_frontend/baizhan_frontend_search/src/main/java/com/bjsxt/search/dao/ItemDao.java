package com.bjsxt.search.dao;

import com.bjsxt.search.pojo.Item;

import java.util.Map;

/**
 * 商品数据访问接口。访问的数据源是Elasticsearch
 */
public interface ItemDao {
    /**
     * 搜索
     * @param q
     * @param page
     * @param rows
     * @return
     */
    Map<String, Object> search(String q, int page, int rows);

    /**
     * 创建索引
     */
    void createIndex();

    /**
     * 设置映射
     */
    void putMapping();

    /**
     * 保存商品数据到Elasticsearch，可以批处理。
     * @param items
     */
    void save(Item... items);
}
