package com.bjsxt.search.dao.impl;

import com.bjsxt.search.dao.ItemDao;
import com.bjsxt.search.pojo.Item;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 商品数据访问实现
 */
@Repository
public class ItemDaoImpl implements ItemDao {
    @Autowired
    private ElasticsearchRestTemplate elasticsearchRestTemplate;

    /**
     * 分页搜索
     * @param q 条件， 在商品的title,sellPoint,categoryName三个字段中做match匹配。
     *          任何字段包含搜索条件，都是搜索结果。
     *          标题数据如果包含搜索条件，需要高亮处理。
     * @param page
     * @param rows
     * @return
     *  Map         key             value
     *              total           复合搜索条件的数据个数
     *              list            当前页面显示的数据集合
     */
    @Override
    public Map<String, Object> search(String q, int page, int rows) {
        // 组织搜索条件
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        boolQueryBuilder.should(
                QueryBuilders.matchQuery("title", q) // 标题
        )
        .should(
                QueryBuilders.matchQuery("sellPoint", q) // 卖点
        )
        .should(
                QueryBuilders.matchQuery("categoryName", q) // 商品分类名
        );
        // 定义高亮字段
        HighlightBuilder.Field titleHl = new HighlightBuilder.Field("title");
        titleHl.preTags("<span style='color:red'>");
        titleHl.postTags("</span>");
        // 搜索
        SearchHits<Item> hits =
                elasticsearchRestTemplate.search(
                        new NativeSearchQueryBuilder()
                                .withQuery(boolQueryBuilder)
                                .withHighlightFields(titleHl)
                                .withPageable(
                                        PageRequest.of(page - 1, rows)
                                )
                                .build(),
                        Item.class
                );
        // 处理搜索结果
        Map<String, Object> data = new HashMap<>();
        data.put("total", hits.getTotalHits());

        List<Item> list = new ArrayList<>(rows);
        for(SearchHit<Item> hit : hits){
            Item item = hit.getContent();
            // 处理高亮
            List<String> title = hit.getHighlightField("title");
            if(title != null && title.size() > 0){
                // 有高亮的标题
                item.setTitle(title.get(0));
            }
            // 把处理高亮后的Item对象，保存到集合list中。
            list.add(item);
        }
        data.put("list", list);

        return data;
    }

    @Override
    public void createIndex() {
        elasticsearchRestTemplate.indexOps(Item.class)
                .create();
    }

    @Override
    public void putMapping() {
        elasticsearchRestTemplate.indexOps(Item.class)
                .putMapping(
                        elasticsearchRestTemplate.indexOps(Item.class)
                            .createMapping()
                );
    }

    @Override
    public void save(Item... items) {
        elasticsearchRestTemplate.save(items);
    }
}
