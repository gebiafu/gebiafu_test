package com.bjsxt.search.service.impl;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.commons.pojo.Item4Elasticsearch;
import com.bjsxt.search.dao.ItemDao;
import com.bjsxt.search.feign.BackendItemFeignClient;
import com.bjsxt.search.pojo.Item;
import com.bjsxt.search.service.SearchService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class SearchServiceImpl implements SearchService {
    @Autowired
    private BackendItemFeignClient backendItemFeignClient;
    @Autowired
    private ItemDao itemDao;

    /**
     * 分页搜索
     * @param q 条件， 在商品的title,sellPoint,categoryName三个字段中做match匹配。
     *          任何字段包含搜索条件，都是搜索结果。
     *          标题数据如果包含搜索条件，需要高亮处理。
     * @param page
     * @param rows
     * @return
     */
    @Override
    public BaizhanResult search(String q, int page, int rows) {
        Map<String, Object> data =
                itemDao.search(q, page, rows);
        data.put("rows", rows);
        return BaizhanResult.ok(data);
    }

    /**
     * 初始化功能。
     * 流程：
     *  1. 基于Openfeign访问后台的item系统，查询要初始化到Elasticsearch的数据
     *  2. 访问Elasticsearch，创建索引，设置Mapping，新增数据
     * @return
     */
    @Override
    public BaizhanResult init() {
        BaizhanResult result =
                backendItemFeignClient.getItems4InitElasticsearch();
        if(result.getStatus() != 200){
            // 远程服务有错误返回
            return BaizhanResult.error("初始化Elasticsearch数据时，调用后台商品服务错误");
        }
        List<LinkedHashMap<Object, Object>> list =
                (List<LinkedHashMap<Object, Object>>) result.getData();

        // 创建索引
        itemDao.createIndex();

        // 设置映射
        itemDao.putMapping();
        // 批量保存时，商品对象存放位置
        Item[] temp = new Item[1000];
        // 计数器，同时也是数组的使用下标
        int index = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        // 批量保存商品数据到Elasticsearch
        for(LinkedHashMap<Object, Object> map : list){
            // 创建需要的对象
            Item item = new Item();
            // 赋值属性
            item.setId(map.get("id").toString());
            item.setTitle(map.get("title").toString());
            item.setSellPoint(map.get("sellPoint").toString());
            item.setPrice(Long.parseLong(map.get("price").toString()));
            item.setImage(map.get("image").toString());
            item.setItemDesc(map.get("itemDesc") == null ? "" : map.get("itemDesc").toString());
            item.setCategoryName(map.get("categoryName").toString());
            try {
                item.setUpdated(sdf.parse(map.get("updated").toString()));
            }catch (Exception e){
                item.setUpdated(null);
            }
            // 把创建好的商品对象保存到数组中。
            temp[index++] = item;
            if(index == 1000){
                // 数组装满，批量保存
                itemDao.save(temp);
                // 重置计数器
                index = 0;
                // 重置数组中的数据
                temp = new Item[1000];
            }
        }
        // 检查数组中是否还有没保存到Elasticsearch中的数据
        if(index > 0){
            // 拷贝temp数组中0~index下标的元素。
            Item[] items =
                Arrays.copyOfRange(temp, 0, index);
            // 还有数据未保存,只保存剩余数据。

            itemDao.save(items);
        }


        return BaizhanResult.ok();
    }
}
