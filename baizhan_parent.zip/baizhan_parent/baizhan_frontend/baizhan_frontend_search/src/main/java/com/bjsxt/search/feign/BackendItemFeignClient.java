package com.bjsxt.search.feign;

import com.bjsxt.commons.pojo.BaizhanResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient("baizhan-backend-item")
public interface BackendItemFeignClient {
    @PostMapping("/backend/item/getItems4InitElasticsearch")
    public BaizhanResult getItems4InitElasticsearch();
}
