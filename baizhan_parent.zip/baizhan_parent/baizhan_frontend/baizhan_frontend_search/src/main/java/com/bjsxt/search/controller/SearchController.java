package com.bjsxt.search.controller;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.search.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 前台 搜索 控制器
 */
@RestController
public class SearchController {
    @Autowired
    private SearchService searchService;

    /**
     * 搜索,分页
     * @return
     */
    @PostMapping("/search/list")
    public BaizhanResult search(String q, int page, int rows){
        return searchService.search(q, page, rows);
    }

    /**
     * 初始化Elasticsearch中的数据。
     * 商业项目中，当前功能是集成在后台商品管理系统中的。
     * 当前项目，后台的前端视图缺少对应功能。
     * @return
     */
    @PostMapping("/frontend/search/init")
    public BaizhanResult init(){
        return searchService.init();
    }
}
