package com.bjsxt.search.service;

import com.bjsxt.commons.pojo.BaizhanResult;

/**
 * 前台 搜索 服务接口
 */
public interface SearchService {
    /**
     * 分页搜索
     * @param q
     * @param page
     * @param rows
     * @return
     */
    BaizhanResult search(String q, int page, int rows);
    /**
     * 初始化方法
     * @return
     */
    BaizhanResult init();
}
