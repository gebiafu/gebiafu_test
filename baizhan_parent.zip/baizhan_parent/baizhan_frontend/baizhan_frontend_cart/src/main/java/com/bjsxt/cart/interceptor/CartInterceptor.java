package com.bjsxt.cart.interceptor;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Component
public class CartInterceptor implements HandlerInterceptor {
    /**
     * 前置拦截
     * 如何判断用户是否已登录？
     * 判断HttpSession（Spring Session管理的分布式会话）中是否有loginUser 命名的Attribute
     *
     * @return true - 已登录，执行后续流程。 false - 未登录，拦截请求。
     *  未登录的时候，响应客户端（前端系统）一个错误状态码403
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        if(session.getAttribute("loginUser") == null){
            // 未登录，返回错误状态码403
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return false;
        }
        // 已登录，执行后续流程
        return true;
    }
}
