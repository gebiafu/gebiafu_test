package com.bjsxt.cart.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbUser;

/**
 * 前台 购物车 服务接口
 */
public interface CartService {
    /**
     * 结算确认
     * @param id 要购买的商品主键数组
     * @return
     */
    BaizhanResult goSettlement(Long[] id, TbUser loginUser);

    /**
     * 移除购物车中的商品
     * @param itemId 商品主键
     * @param loginUser 登录用户
     * @return
     */
    BaizhanResult removeItemFromCart(Long itemId, TbUser loginUser);

    /**
     * 修改购物车中商品数量
     * @param itemId 商品主键
     * @param num 修改后的数量
     * @param loginUser 登录用户
     * @return
     */
    BaizhanResult changeItemNum(Long itemId, int num, TbUser loginUser);

    /**
     * 增加商品到购物车
     * @param itemId 商品主键
     * @param num 预计购买数量
     * @param loginUser 登录用户
     * @return
     */
    BaizhanResult addItem2Cart(Long itemId, int num, TbUser loginUser);

    /**
     * 显示用户的购物车。
     * @param loginUser 当前登录的用户对象
     * @return
     */
    BaizhanResult showCart(TbUser loginUser);
}
