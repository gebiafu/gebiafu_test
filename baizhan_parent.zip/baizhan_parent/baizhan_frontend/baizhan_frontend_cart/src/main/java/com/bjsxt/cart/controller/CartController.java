package com.bjsxt.cart.controller;

import com.bjsxt.cart.service.CartService;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

/**
 * 前台 购物车 控制器
 */
@RestController
public class CartController {
    @Autowired
    private CartService cartService;

    /**
     * 结算确认，显示要购买的商品信息和对应的小计。
     * @param id 所有要购买的商品主键数组
     * @return 必须包含每个商品库存量是否足够。
     */
    @PostMapping("/cart/goSettlement")
    public BaizhanResult goSettlement(Long[] id, HttpSession session){
        return cartService.goSettlement(id, (TbUser) session.getAttribute("loginUser"));
    }

    /**
     * 从购物车中移除商品
     * @param itemId 商品主键
     * @param session
     * @return
     */
    @PostMapping("/cart/deleteItemFromCart")
    public BaizhanResult removeItemFromCart(Long itemId, HttpSession session){
        TbUser loginUser = (TbUser) session.getAttribute("loginUser");
        return cartService.removeItemFromCart(itemId, loginUser);
    }

    /**
     * 修改购物车中商品的数量
     * @param itemId 商品主键
     * @param num 修改后的数量
     * @param session
     * @return
     */
    @PostMapping("/cart/updateItemNum")
    public BaizhanResult changeItemNum(Long itemId, int num, HttpSession session){
        TbUser loginUser = (TbUser) session.getAttribute("loginUser");
        return cartService.changeItemNum(itemId, num, loginUser);
    }

    /**
     * 增加商品到购物车
     * @param itemId 商品主键
     * @param num 预计购买数量
     * @param session
     * @return
     */
    @GetMapping("/cart/addItem")
    public BaizhanResult addItem2Cart(Long itemId, int num, HttpSession session){
        TbUser loginUser = (TbUser) session.getAttribute("loginUser");
        return cartService.addItem2Cart(itemId, num, loginUser);
    }

    /**
     * 显示购物车中的所有商品数据。
     * 找到当前登录用户的购物车，把Map集合的values返回。
     * 用户的购物车在哪？
     *  购物车是临时数据，不是持久数据。不能保存到关系型数据库中。
     *  保存到Redis中。key是前缀+登录用户的主键。value是Cart类型对象。
     * @return
     */
    @PostMapping("/cart/showCart")
    public BaizhanResult showCart(HttpSession session){
        TbUser loginUser = (TbUser) session.getAttribute("loginUser");
        return cartService.showCart(loginUser);
    }
}
