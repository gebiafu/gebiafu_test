package com.bjsxt.cart.service.impl;

import com.bjsxt.cart.feign.FrontendDetailsFeignClient;
import com.bjsxt.cart.service.CartService;
import com.bjsxt.cart.vo.Cart;
import com.bjsxt.cart.vo.CartItem;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.dao.RedisDao;
import com.bjsxt.pojo.TbItem;
import com.bjsxt.pojo.TbUser;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 前台 购物车 服务实现
 */
@Service
public class CartServiceImpl implements CartService {
    @Autowired
    private RedisDao redisDao;
    @Value("${baizhan.cart.keyPrefix}")
    private String cartKeyPrefix;
    @Value("${baizhan.details.itemKeyPrefix}")
    private String itemKeyPrefix;
    @Autowired
    private FrontendDetailsFeignClient frontedDetailsFeignClient;

    /**
     * 确认方法
     * 流程：
     *  1. 查询购物车
     *  2. 获取购物车中所有要购买的商品数据
     *  3. 访问Redis，查询商品的剩余库存，填充CartItem对象的enough属性。
     *  4. 返回结果。
     * @param id 要购买的商品主键数组
     * @return
     */
    @Override
    public BaizhanResult goSettlement(Long[] id, TbUser loginUser) {
        // 查购物车
        String key = cartKeyPrefix + loginUser.getId();
        Cart cart = redisDao.get(key);
        if(cart == null){
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
        // 获取购物车中所有要购买的商品
        List<CartItem> items = new ArrayList<>(id.length);
        for(Long itemId : id){
            CartItem cartItem = cart.getCarts().get(itemId.toString());
            if(cartItem != null){
                // 商品存在， 访问Redis，查询商品的库存
                String itemKey = itemKeyPrefix + itemId;
                TbItem item = redisDao.get(itemKey);
                if(item == null){
                    // 商品在redis中的缓存数据过期了。
                    // 调用Details子系统中的商品查询服务。
                    BaizhanResult detailsResult =
                            frontedDetailsFeignClient.getItemById(itemId);
                    if(detailsResult.getStatus() == 200){
                        item = map2Item((LinkedHashMap) detailsResult.getData());
                    }else{
                        // 如果商品不存在，则提供一个降级数据，一定库存不够的数据
                        item = new TbItem();
                        item.setId(itemId);
                        item.setNum(0);
                    }
                }
                // 设置要购买的商品库存是否足够
                cartItem.setEnough(item.getNum() >= cartItem.getNum());

                items.add(cartItem);
            }
        }
        return BaizhanResult.ok(items);
    }

    private TbItem map2Item(Map<String, Object> map){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        TbItem item = new TbItem();
        item.setId((Long) map.get("id"));
        try {
            item.setUpdated(sdf.parse(map.get("updated").toString()));
        } catch (ParseException e) {
            item.setUpdated(null);
            e.printStackTrace();
        }
        try {
            item.setCreated(sdf.parse(map.get("created").toString()));
        } catch (ParseException e) {
            item.setCreated(null);
            e.printStackTrace();
        }
        item.setNum((int) map.get("num"));
        item.setStatus((Integer) map.get("status"));
        item.setBarcode(map.get("barcode") == null ? "" : map.get("barcode").toString());
        item.setCid((Long) map.get("cid"));
        item.setImage(map.get("image") == null ? "" : map.get("image").toString());
        item.setPrice((Long) map.get("price"));
        item.setSellPoint(map.get("sellPoint") == null ? "" : map.get("sellPoint").toString());
        item.setTitle(map.get("title") == null ? "" : map.get("title").toString());
        return item;
    }

    /**
     * 流程：
     *  1. 查询购物车
     *  2. 商品购物车中的商品
     * @param itemId 商品主键
     * @param loginUser 登录用户
     * @return
     */
    @Override
    public BaizhanResult removeItemFromCart(Long itemId, TbUser loginUser) {
        String key = cartKeyPrefix + loginUser.getId();
        Cart cart = redisDao.get(key);
        if(cart == null){
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
        // 删除购物车中的指定商品
        cart.removeItemFromCart(itemId);

        // 保存修改后的购物车到Redis
        redisDao.set(key, cart);
        return BaizhanResult.ok();
    }

    /**
     * 流程：
     *  1. 查询购物车
     *  2. 修改商品数量
     * @param itemId 商品主键
     * @param num 修改后的数量
     * @param loginUser 登录用户
     * @return
     */
    @Override
    public BaizhanResult changeItemNum(Long itemId, int num, TbUser loginUser) {
        String key = cartKeyPrefix + loginUser.getId();
        Cart cart = redisDao.get(key);
        if(cart == null){
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
        // 改购物车中的商品预计购买数量
        cart.changeItemNum(itemId, num);

        // 把改变的购物车保存到Redis中
        redisDao.set(key, cart);
        return BaizhanResult.ok();
    }

    /**
     * 执行流程：
     *  1. 从Redis中查询购物车
     *  2. 在购物车中比较是否有相同的商品
     *  3. 如果有相同的商品，预计购买数量累加
     *  4. 如果没有相同的商品，从Redis中查询商品缓存数据，并增加到购物车中。
     * @param itemId 商品主键
     * @param num 预计购买数量
     * @param loginUser 登录用户
     * @return
     */
    @Override
    public BaizhanResult addItem2Cart(Long itemId, int num, TbUser loginUser) {
        String key = cartKeyPrefix + loginUser.getId();
        Cart cart = redisDao.get(key);
        if(cart == null){
            // 购物车不存在，创建一个新的。
            cart = new Cart();
        }
        // 比较购物车中的商品是否有同主键的数据。
        boolean hasItem = cart.containsCartItem(itemId, num);
        if(!hasItem){
            // 没有同主键的商品，从Redis中查询商品数据
            String itemKey = itemKeyPrefix + itemId;
            TbItem tbItem = redisDao.get(itemKey);
            CartItem cartItem = new CartItem();
            // 赋值商品数据到购物车商品对象中。
            BeanUtils.copyProperties(tbItem, cartItem);
            // 修改购物车商品对象的预计购买数量。
            cartItem.setNum(num);
            // 把购物车商品对象，增加到购物车中。
            cart.addCartItem2Cart(cartItem);
        }

        // 把变化后的购物车数据，保存到Redis中
        redisDao.set(key, cart);

        return BaizhanResult.ok();
    }

    /**
     * 查询登录用户的购物车
     * @param loginUser 当前登录的用户对象
     * @return
     */
    @Override
    public BaizhanResult showCart(TbUser loginUser) {
        String key = cartKeyPrefix + loginUser.getId();

        // 从Redis中查询登录用户的购物车
        Cart cart = redisDao.get(key);

        // 用户的购物车未必存在
        if(cart == null){
            cart = new Cart();
            // 可选操作：购物车不存在，把创建的新的购物车，保存到Redis中。
            // 避免下次查询的时候，还需要创建。
            redisDao.set(key, cart);
        }

        // 获取购物车中的所有的商品数据集合。
        Collection<CartItem> cartItems = cart.showCart();

        return BaizhanResult.ok(cartItems);
    }
}
