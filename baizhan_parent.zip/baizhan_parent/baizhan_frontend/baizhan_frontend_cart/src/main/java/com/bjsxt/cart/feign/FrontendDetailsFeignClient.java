package com.bjsxt.cart.feign;

import com.bjsxt.commons.pojo.BaizhanResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient("baizhan-frontend-details")
public interface FrontendDetailsFeignClient {
    @PostMapping("/item/selectItemInfo")
    BaizhanResult getItemById(@RequestParam("id") Long id);
}
