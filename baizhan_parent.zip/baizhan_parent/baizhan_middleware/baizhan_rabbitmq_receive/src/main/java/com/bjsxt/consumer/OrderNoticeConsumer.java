package com.bjsxt.consumer;

import com.bjsxt.message.pojo.notice.OrderNoticeMessage;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.internet.MimeMessage;

/**
 * 订单确认消息消费者
 */
@Component
public class OrderNoticeConsumer {
    /**
     * 用于发送电子邮件的Java客户端
     * 创建的时候，需要提供
     *  发件人的邮箱地址，登录方式。
     */
    @Autowired
    private JavaMailSender javaMailSender;
    // 发邮件的邮箱地址
    @Value("${spring.mail.username}")
    private String from;

    /**
     * 订单确认通知消费者
     *  发送邮件给购买者。
     * @param message
     */
    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue(name = "${baizhan.notice.mailAndSms.queue}", autoDelete = "false"),
                    exchange = @Exchange(name = "${baizhan.notice.mailAndSms.exchange}", type = "${baizhan.notice.mailAndSms.exchangeType}"),
                    key = "${baizhan.notice.mailAndSms.routingKey}"
            )
    })
    public void onMessage(OrderNoticeMessage message){
        // 发送邮件的时候，就是编写一个邮件，并发送。
        // 邮件内容包括：发件人，收件人，主题，正文
        // 基于发送邮件的工具创建一个邮件对象
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        // 创建一个邮件对象帮助工具。辅助快速创建邮件的内容。
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage);
        try {
            helper.setFrom(from); // 发件人
            helper.setTo(message.getEmail());// 收件人
            helper.setSubject("百战电子商务平台-订单确认邮件"); // 主题
            StringBuilder builder = new StringBuilder("");
            builder.append("<div>");
            builder.append(message.getName());
            builder.append("先生/女士");
            builder.append("</div>");
            builder.append("<div>");
            builder.append("您编号为'")
                    .append("<span style='color:red'>")
                    .append(message.getOrderId())
                    .append("</span>")
                    .append("'的订单，已成功创建，请尽快支付。");
            builder.append("</div>");
            builder.append("<div style='text-align:right'>")
                    .append("百战电子商务平台")
                    .append("</div>");
            helper.setText(builder.toString(), true); // 正文，正文支持HTML标签

            // 把设置好邮件内容的对象生成
            mimeMessage = helper.getMimeMessage();
            // 发送邮件
            javaMailSender.send(mimeMessage);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
