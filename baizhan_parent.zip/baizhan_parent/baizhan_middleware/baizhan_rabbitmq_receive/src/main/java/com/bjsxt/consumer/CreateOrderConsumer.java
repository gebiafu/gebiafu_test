package com.bjsxt.consumer;

import com.bjsxt.feign.BackendItemFeignClient;
import com.bjsxt.feign.FrontendTradeFeignClient;
import com.bjsxt.message.pojo.order.CreateOrderMessage;
import com.bjsxt.message.sender.MessageSender;
import com.bjsxt.pojo.TbOrderItem;
import com.codingapi.txlcn.tc.annotation.LcnTransaction;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 创建订单消息消费者
 */
@Component
public class CreateOrderConsumer {
    @Autowired
    private BackendItemFeignClient itemFeignClient;
    @Autowired
    private FrontendTradeFeignClient tradeFeignClient;
    @Autowired
    private MessageSender messageSender;
    @Value("${baizhan.trade.create.exchange}")
    private String createExchange;
    @Value("${baizhan.trade.create.routingKey}")
    private String createRoutingKey;


    /**
     * 创建订单消息消费者
     * 实现方式:
     *  1. 本地访问数据库。使用本地事务，本地逻辑。原子性好。相对代码耦合度高。
     *  2. 远程服务实现。调用订单系统服务中的创建订单、订单物流、订单项等方法新增数据。
     *     调用details服务中的修改商品库存，修改数据。
     *     分布式事务管理，相对有延迟，代码耦合度低。
     *     frontend-trade工程 - trade提供新增订单，订单物流，订单项的方法。
     *     backend-item工程 - 提供修改商品库存的方法。
     * @param message
     */
    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue(name = "${baizhan.trade.create.queue}", autoDelete = "false"),
                    exchange = @Exchange(name = "${baizhan.trade.create.exchange}", type = "${baizhan.trade.create.exchangeType}"),
                    key = "${baizhan.trade.create.routingKey}"
            )
    })
    public void onMessage(CreateOrderMessage message){
        try{
            doMessage(message);
        }catch (Exception e){
            // 有异常的时候，说明分布式事务回滚了。大概率是数据库访问异常，网络异常等极端情况。
            // 流程是先锁定库存，后数据库变化。有异常的可能极低。
            // 把创建订单的消息，重新发到MQ中，再次消费。可以计算次数，如果重试次数过多
            // 再回滚取消库存的锁定。
            if(message.getTimes() < 10){
                // 同样的消息，再次发送到MQ中。计数+1。
                message.setTimes(message.getTimes() + 1);
                messageSender.sendMessage(createExchange, createRoutingKey, message);
            }else{
                // 像订单项目中恢复库存一样的逻辑。
            }
        }
    }

    /**
     * 真实调用远程服务，实现新增订单相关数据，修改商品库存数据的方法。
     * 需要管理分布式事务。
     * @param message
     */
    @Transactional
    @LcnTransaction
    public void doMessage(CreateOrderMessage message){
        // 处理新增订单相关数据
        Map<String, Object> orderDataMap = new HashMap<>();
        orderDataMap.put("order", message.getOrder());
        orderDataMap.put("orderShipping", message.getOrderShipping());
        orderDataMap.put("orderItems", message.getOrderItems());
        // 调用远程方法。
        tradeFeignClient.insertOrder2DB(orderDataMap);

        // 处理修改商品库存的相关数据
        List<TbOrderItem> orderItems = message.getOrderItems();
        Map<Long, Integer> itemDataMap = new HashMap<>();
        for(TbOrderItem orderItem : orderItems){
            itemDataMap.put(orderItem.getItemId(), orderItem.getNum());
        }
        itemFeignClient.modifyItemNum4CreateOrder(itemDataMap);
    }
}
