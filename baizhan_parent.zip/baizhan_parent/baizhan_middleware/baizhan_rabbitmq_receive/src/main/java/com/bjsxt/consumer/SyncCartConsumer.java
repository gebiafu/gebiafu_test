package com.bjsxt.consumer;

import com.bjsxt.cart.vo.Cart;
import com.bjsxt.dao.RedisDao;
import com.bjsxt.message.pojo.cart.SyncCartMessage;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 同步购物车消费者
 */
@Component
public class SyncCartConsumer {
    @Autowired
    private RedisDao redisDao;
    @Value("${baizhan.cart.keyPrefix}")
    private String cartKeyPrefix;

    /**
     * 同步购物车消费者。
     * 要访问的是Redis，直接访问即可。
     * 流程：
     *  1. 从Redis中查询购物车
     *  2. 删除已购买的商品
     *  3. 保存修改后的购物车到Redis
     * @param message
     */
    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue(name = "${baizhan.cart.sync.queue}", autoDelete = "false"),
                    exchange = @Exchange(name = "${baizhan.cart.sync.exchange}", type = "${baizhan.cart.sync.exchangeType}"),
                    key = "${baizhan.cart.sync.routingKey}"
            )
    })
    public void onMessage(SyncCartMessage message){
        // 查询购物车
        String key = cartKeyPrefix + message.getUserId();
        Cart cart = redisDao.get(key);
        // 删除购物车中已购买的商品
        List<Long> ids = message.getItemIds();
        for(Long id : ids){
            cart.removeItemFromCart(id);
        }
        // 保存修改后的购物车到Redis
        redisDao.set(key, cart);
    }
}
