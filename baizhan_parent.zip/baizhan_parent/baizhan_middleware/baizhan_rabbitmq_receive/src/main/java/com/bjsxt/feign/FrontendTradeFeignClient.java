package com.bjsxt.feign;

import com.bjsxt.commons.pojo.BaizhanResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@FeignClient("baizhan-frontend-trade")
public interface FrontendTradeFeignClient {
    /**
     * 新增订单，订单物流，订单项
     * @param params 要新增的数据集合。请求体传递
     *               key            value
     *               order          TbOrder类型对象，要新增的订单
     *               orderShipping  TbOrderShipping类型对象，订单物流
     *               orderItems     List<TbOrderItem>类型的集合，订单项集合
     */
    @PostMapping("/order/insertOrder2DB")
    public BaizhanResult insertOrder2DB(@RequestBody Map<String, Object> params);
}
