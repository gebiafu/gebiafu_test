package com.bjsxt.feign;

import com.bjsxt.commons.pojo.BaizhanResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@FeignClient("baizhan-backend-item")
public interface BackendItemFeignClient {
    @PostMapping("/backend/item/modifyItemNum4CreateOrder")
    public BaizhanResult modifyItemNum4CreateOrder(@RequestBody Map<Long, Integer> params);
}
