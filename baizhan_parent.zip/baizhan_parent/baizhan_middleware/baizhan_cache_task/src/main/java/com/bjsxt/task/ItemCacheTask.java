package com.bjsxt.task;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.dao.RedisDao;
import com.bjsxt.mapper.TbItemDescMapper;
import com.bjsxt.mapper.TbItemMapper;
import com.bjsxt.mapper.TbItemParamItemMapper;
import com.bjsxt.pojo.TbItem;
import com.bjsxt.pojo.TbItemDesc;
import com.bjsxt.pojo.TbItemParamItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 商品缓存任务类型
 * 定时周期执行， 类型的对象必须被Spring容器管理
 */
@Component
public class ItemCacheTask {
    @Value("${baizhan.details.itemKeyPrefix}")
    private String itemKeyPrefix;
    @Value("${baizhan.details.itemDescKeyPrefix}")
    private String itemDescKeyPrefix;
    @Value("${baizhan.details.itemParamItemKeyPrefix}")
    private String itemParamItemKeyPrefix;
    @Autowired
    private TbItemMapper itemMapper;
    @Autowired
    private TbItemDescMapper itemDescMapper;
    @Autowired
    private TbItemParamItemMapper itemParamItemMapper;
    @Autowired
    private RedisDao redisDao;

    /**
     * 任务方法。
     * 要求： 没有返回值，没有参数，任意命名，公开访问修饰符
     *
     * 内容：
     *  查询数据库中的商品相关数据，缓存到Redis中。
     *
     * Scheduled - 定时任务注解。当前方法基于CRON表达式，定时周期执行。
     *  CRON表达式：    *        *       *       *       *       *
     *  分别代表        秒       分钟    小时     天      月      周
     *  取值          0~59       0~59    0~23    1~31   1~12    0~54
     *  可选常用其他值    * 代表任意。 / 代表步长
     *  如： 0 * * * * *  每分钟的第0秒运行
     *  如： 0 0 * * * *  每小时的第0分0秒运行
     *  如： ※/2  * * * * *   每一个偶数秒运行
     */
    @Scheduled(cron = "0 * * * * *")
    public void itemCacheTask(){
        // 访问数据库，查询要缓存的热门商品数据集合
        List<TbItem> items = itemMapper.selectList(
                new QueryWrapper<TbItem>().ge("id", 1433500495290L)
        );
        List<TbItemDesc> itemDescs = itemDescMapper.selectList(
                new QueryWrapper<TbItemDesc>().ge("item_id", 1433500495290L)
        );
        List<TbItemParamItem> itemParamItems = itemParamItemMapper.selectList(
                new QueryWrapper<TbItemParamItem>().ge("item_id", 1433500495290L)
        );
        // 把数据缓存到Redis中
        for(TbItem item : items){
            redisDao.set(itemKeyPrefix + item.getId(), item, 7L, TimeUnit.DAYS);
        }

        for(TbItemDesc itemDesc : itemDescs){
            redisDao.set(itemDescKeyPrefix + itemDesc.getItemId(), itemDesc, 7L, TimeUnit.DAYS);
        }

        for(TbItemParamItem itemParamItem : itemParamItems){
            redisDao.set(itemParamItemKeyPrefix + itemParamItem.getItemId(), itemParamItem, 7L, TimeUnit.DAYS);
        }
    }
}
