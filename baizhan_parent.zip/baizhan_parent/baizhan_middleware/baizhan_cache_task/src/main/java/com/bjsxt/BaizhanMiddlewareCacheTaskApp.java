package com.bjsxt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * EnableScheduling - 开启Spring定时任务处理能力。
 *  定时任务，在应用中使用，当前应用启动后回长期保持。
 *  底层是Spring开启一个服务线程，长期监听定时任务。做周期运行。
 */
@SpringBootApplication
@EnableScheduling
public class BaizhanMiddlewareCacheTaskApp {
    public static void main(String[] args) {
        SpringApplication.run(BaizhanMiddlewareCacheTaskApp.class, args);
    }
}
