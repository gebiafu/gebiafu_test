package com.bjsxt.item.mapper;

import com.bjsxt.commons.pojo.Item4Elasticsearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ItemMapper {
    /**
     * 查询所有的商品，附带商品分类名和商品详情
     * @return
     */
    @Select("select i.id, i.title, i.sell_point as sellPoint, i.price, i.image, i.updated, " +
            "cat.name as categoryName, d.item_desc as itemDesc " +
            "from tb_item i left join tb_item_cat cat on i.cid = cat.id " +
            "left join tb_item_desc d on i.id = d.item_id " +
            "where i.status = 1")
    List<Item4Elasticsearch> selectAll();
}
