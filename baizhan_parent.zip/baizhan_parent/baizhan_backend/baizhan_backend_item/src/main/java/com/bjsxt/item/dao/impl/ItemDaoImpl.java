package com.bjsxt.item.dao.impl;

import com.bjsxt.item.dao.ItemDao;
import com.bjsxt.item.pojo.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.stereotype.Repository;

/**
 * ElasticSearch数据访问实现
 */
@Repository
public class ItemDaoImpl implements ItemDao {
    @Autowired
    private ElasticsearchRestTemplate elasticsearchRestTemplate;

    @Override
    public void save(Item item) {
        elasticsearchRestTemplate.save(item);
    }

    @Override
    public void delete(String id) {
        elasticsearchRestTemplate.delete(id, Item.class);
    }
}
