package com.bjsxt.itemparam.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbItemParam;

/**
 * 后台商品规格服务接口
 */

public interface ItemParamService {
    BaizhanResult getItemParamAll();

    /**
     * 根据商品分类主键，查询规格
     * @param itemCatId
     * @return
     */
    BaizhanResult getItemParamByItemCategoryId(Long itemCatId);

    /**
     * 根据主键删除规格
     * @param id
     * @return
     */
    BaizhanResult removeItemParamById(Long id);

    /**
     * 根据商品分类主键，查询商品规格
     * @param itemCatId
     * @return
     */
    BaizhanResult getHasItemParamByItemCatId(Long itemCatId);

    /**
     * 创建规格参数
     * @param itemParam
     * @return
     */
    BaizhanResult createItemParam(TbItemParam itemParam);
}
