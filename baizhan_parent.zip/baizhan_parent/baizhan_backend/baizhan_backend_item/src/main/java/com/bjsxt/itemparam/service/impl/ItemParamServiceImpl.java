package com.bjsxt.itemparam.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.itemparam.service.ItemParamService;
import com.bjsxt.mapper.TbItemParamMapper;
import com.bjsxt.pojo.TbItemParam;
import com.bjsxt.utils.IDUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * 后台商品规格服务实现
 */
@Service
public class ItemParamServiceImpl implements ItemParamService {
    // 商品规格数据库访问接口
    @Autowired
    private TbItemParamMapper itemParamMapper;

    /**
     * 根据商品分类主键，查询规格
     * MyBatisPlus 提供的查询单数据的方法 selectOne， 如果查询结果不存在，返回null；
     * 查询结果大于1条数据，抛出异常。
     * @param itemCatId
     * @return
     */
    @Override
    public BaizhanResult getItemParamByItemCategoryId(Long itemCatId) {
        try {
            QueryWrapper<TbItemParam> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("item_cat_id", itemCatId);
            TbItemParam itemParam = itemParamMapper.selectOne(queryWrapper);
            if(null == itemParam){
                return BaizhanResult.error("商品分类无规格，请提前定义");
            }
            return BaizhanResult.ok(itemParam);
        }catch (Exception e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 根据主键删除数据库中的规格。
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult removeItemParamById(Long id) {
        try {
            int rows = itemParamMapper.deleteById(id);
            if (rows != 1) {
                // 删除失败
                throw new DaoException("根据主键删除规格错误");
            }
            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("根据主键删除规格时，MyBatis错误：" + e.getMessage());
        }
    }

    /**
     * 新增商品规格到数据库
     * 分布式项目中，数据库表格的主键自增不要使用。除非领导安排使用主键自增策略。
     * 否则都用代码或其他方式，生成唯一主键。
     * 原因： 分布式项目中的数据库，也可能是分布式集群架构的。
     *        多个数据库服务器，都使用主键自增，可能有重复主键。逻辑错误。
     * @param itemParam 请求参数有规格所对应的商品分类主键item_cat_id，JSON格式的字符串param_data。
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult createItemParam(TbItemParam itemParam) {
        try {
            // 给TbItemParam对象属性赋值。提供需要的各种数据
            // 提供主键
            itemParam.setId(IDUtils.genItemId());
            // 提供创建时间和更新时间
            Date now = new Date();
            itemParam.setCreated(now);
            itemParam.setUpdated(now); // 可以省略

            // 新增数据到数据库
            int rows = itemParamMapper.insert(itemParam);
            if (rows != 1) {
                // 新增错误
                throw new DaoException("新增商品规格到数据库错误");
            }
            return BaizhanResult.ok();
        }catch (DaoException e){
            // 自己抛出的异常
            throw e;
        }catch (Exception e){
            // MyBatis代码可能抛出的异常。
            throw new DaoException("新增商品规格到数据库时，MyBatis发生异常，异常信息是："
                    + e.getMessage());
        }
    }

    /**
     * 根据商品分类主键，查询是否有对应的商品规格
     * @param itemCatId
     * @return
     */
    @Override
    public BaizhanResult getHasItemParamByItemCatId(Long itemCatId) {
        QueryWrapper<TbItemParam> queryWrapper =
                new QueryWrapper<>();
        queryWrapper.eq("item_cat_id", itemCatId);

        List<TbItemParam> list = itemParamMapper.selectList(queryWrapper);
        // 判断当前参数商品类型主键，是否有对应的规格，就是检查，查询结果集合长度是否大于0.

        return list.size() > 0 ? BaizhanResult.error("商品分类已存在规格") : BaizhanResult.ok();
    }

    /**
     * 查询商品规格。不分页，查询全部。
     * 访问表格tb_item_param。
     * MyBatisPlus提供的数据库访问接口类名一定和表格名相关。
     *  一般是表格名称，删除下划线，每个单词首字母大写。可能会删除表格前缀名tb_
     *  接口名称是TbItemParamMapper或ItemParamMapper。
     *
     *  接口的查询方法，都是selectXxx。
     *  如果没有查询条件，方法参数传递null或者创建一个对应类型的对象即可。
     * @return
     */
    @Override
    public BaizhanResult getItemParamAll() {
        /**
         * 查询结果的类型或泛型，一定是当前接口对应的实体类型。
         */
        List<TbItemParam> list = itemParamMapper.selectList(null);
        return BaizhanResult.ok(list);
    }
}
