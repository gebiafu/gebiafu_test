package com.bjsxt.item.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@Document(indexName = "baizhan_item", shards = 1, replicas = 0)
public class Item implements Serializable {
    @Id
    @Field(name = "id", type = FieldType.Keyword)
    private String id;
    @Field(name = "title", type = FieldType.Text, analyzer = "ik_max_word")
    private String title;
    @Field(name = "sellPoint", type = FieldType.Text, analyzer = "ik_max_word")
    private String sellPoint;
    @Field(name = "price", type = FieldType.Long)
    private Long price;
    @Field(name = "image", type = FieldType.Keyword, index = false)
    private String image;
    @Field(name = "categoryName", type = FieldType.Text, analyzer = "ik_max_word")
    private String categoryName;
    @Field(name = "itemDesc", type = FieldType.Text, analyzer = "ik_smart")
    private String itemDesc;
    @Field(name = "updated", type = FieldType.Date, format = DateFormat.basic_date_time)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updated;
}

