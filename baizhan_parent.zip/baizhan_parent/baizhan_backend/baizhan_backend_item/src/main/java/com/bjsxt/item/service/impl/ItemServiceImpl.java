package com.bjsxt.item.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.commons.pojo.Item4Elasticsearch;
import com.bjsxt.dao.RedisDao;
import com.bjsxt.item.dao.ItemDao;
import com.bjsxt.item.mapper.ItemMapper;
import com.bjsxt.item.pojo.Item;
import com.bjsxt.item.service.ItemService;
import com.bjsxt.mapper.TbItemCatMapper;
import com.bjsxt.mapper.TbItemDescMapper;
import com.bjsxt.mapper.TbItemMapper;
import com.bjsxt.mapper.TbItemParamItemMapper;
import com.bjsxt.pojo.TbItem;
import com.bjsxt.pojo.TbItemCat;
import com.bjsxt.pojo.TbItemDesc;
import com.bjsxt.pojo.TbItemParamItem;
import com.bjsxt.utils.IDUtils;
import com.codingapi.txlcn.tc.annotation.LcnTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 后台商品服务实现
 */
@Service
public class ItemServiceImpl implements ItemService {
    @Autowired
    private TbItemMapper itemMapper;
    @Autowired
    private TbItemDescMapper itemDescMapper;
    @Autowired
    private TbItemParamItemMapper itemParamItemMapper;
    @Autowired
    private TbItemCatMapper itemCatMapper;
    @Autowired
    private ItemMapper mapper;
    @Autowired
    private ItemDao itemDao;
    @Autowired
    private RedisDao redisDao;
    @Value("${baizhan.details.itemKeyPrefix}")
    private String itemKeyPrefix;
    @Value("${baizhan.details.itemDescKeyPrefix}")
    private String itemDescKeyPrefix;
    @Value("${baizhan.details.itemParamItemKeyPrefix}")
    private String itemParamItemKeyPrefix;

    /**
     * 创建订单时，修改商品库存
     * @param params
     * @return
     */
    @Override
    @Transactional
    @LcnTransaction
    public BaizhanResult modifyItemNum4CreateOrder(Map<Long, Integer> params) {

        Date now = new Date();
        int rows = 0;
        try {
            for (Map.Entry<Long, Integer> entry : params.entrySet()) {
                Long itemId = entry.getKey();
                Integer num = entry.getValue();
                TbItem item = itemMapper.selectById(itemId);
                item.setNum(item.getNum() - num);
                item.setUpdated(now);
                rows += itemMapper.updateById(item);

            }
            if (rows != params.size()) {
                throw new DaoException("修改商品库存错误");
            }

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("修改商品库存时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 查询的数据包括商品数据tb_item表格，商品详情tb_item_desc表格，
     * 商品分类tb_item_cat表格。
     * @return
     */
    @Override
    public BaizhanResult getItems4InitElasticsearch() {
        List<Item4Elasticsearch> list = mapper.selectAll();
        return BaizhanResult.ok(list);
    }

    /**
     * 更新商品数据
     * @param item
     * @param itemDesc
     * @param itemParamItem
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult modifyItem(TbItem item, TbItemDesc itemDesc, TbItemParamItem itemParamItem) {
        // 补充数据的完整性
        Date updated = new Date();
        item.setUpdated(updated); // 更新时间
        item.setStatus(
                itemMapper.selectById(item.getId()).getStatus()
        ); // 设置原商品状态

        // 商品图文信息
        itemDesc.setUpdated(updated);
        itemDesc.setItemId(item.getId()); // 图文介绍的主键，就是商品的主键

        // 商品具体规格
        itemParamItem.setUpdated(updated);
        itemParamItem.setItemId(item.getId()); // 商品的主键

        try {
            // 更新
            // 更新商品
            int rows = itemMapper.updateById(item);
            if (rows != 1) {
                throw new DaoException("商品更新错误 - 更新数据到tb_item表格错误");
            }
            // 更新商品图文介绍
            rows = itemDescMapper.updateById(itemDesc);
            if (rows != 1) {
                throw new DaoException("商品更新错误 - 更新数据到tb_item_desc表格错误");
            }
            // 更新具体规格，具体规格数据不存在主键。需要提供其他的更新条件
            QueryWrapper<TbItemParamItem> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("item_id", item.getId());
            rows = itemParamItemMapper.update(itemParamItem, queryWrapper);
            if (rows != 1) {
                throw new DaoException("商品更新错误 - 更新数据到tb_item_param_item表格错误");
            }

            // 更新数据到MySQL后，同步到Elasticsearch中
            // 数据新增到数据库MySQL后，同步到Elasticsearch中。
            if(item.getStatus() == 1) { // 商品状态为上架状态，需要双写一致
                Item item4ES = new Item();
                item4ES.setId(item.getId().toString());
                item4ES.setTitle(item.getTitle());
                item4ES.setImage(item.getImage());
                item4ES.setItemDesc(itemDesc.getItemDesc());
                item4ES.setPrice(item.getPrice());
                item4ES.setSellPoint(item.getSellPoint());
                item4ES.setCategoryName(
                        itemCatMapper.selectById(item.getCid()).getName()
                );
                item4ES.setUpdated(item.getUpdated());

                // 保存Item到Elasticsearch
                itemDao.save(item4ES);

                // 保存商品相关数据到Redis，新增缓存或覆盖缓存
                redisDao.set(itemKeyPrefix+item.getId(),
                        itemMapper.selectById(item.getId()),
                        7L, TimeUnit.DAYS);
                redisDao.set(itemDescKeyPrefix+item.getId(),
                        itemDescMapper.selectById(item.getId()),
                        7L, TimeUnit.DAYS);
                redisDao.set(itemParamItemKeyPrefix+item.getId(),
                        itemParamItemMapper.selectOne(
                                new QueryWrapper<TbItemParamItem>()
                                        .eq("item_id", item.getId())),
                        7L, TimeUnit.DAYS);
            }

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("商品更新错误 - 数据库访问错误 ： " + e.getMessage());
        }
    }

    /**
     * 预更新
     * @param id
     * @return
     */
    @Override
    public BaizhanResult getItemPreModify(Long id) {

        // 主键查询商品
        TbItem item = itemMapper.selectById(id);
        if(item == null){
            return BaizhanResult.error("商品不存在，请仔细检查");
        }
        // 主键查询商品分类
        TbItemCat itemCat = itemCatMapper.selectById(item.getCid());
        // 主键查询商品的图文介绍。
        TbItemDesc itemDesc = itemDescMapper.selectById(item.getId());
        // 条件查询商品具体的规格
        QueryWrapper<TbItemParamItem> queryWrapper =
                new QueryWrapper<>();
        queryWrapper.eq("item_id", item.getId());
        TbItemParamItem itemParamItem =
                itemParamItemMapper.selectOne(queryWrapper);

        // 返回结果
        Map<String, Object> data = new HashMap<>();
        data.put("item", item);
        data.put("itemCat", itemCat);
        data.put("itemDesc", itemDesc);
        data.put("itemParamItem", itemParamItem);

        return BaizhanResult.ok(data);
    }

    /**
     * 下架商品
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult offshelfItemById(Long id) {
        // 下架
        try {
            int rows = updateItemStatus(id, 2);
            if (rows != 1) {
                throw new DaoException("下架商品错误");
            }

            // 下架成功后，删除Elasticsearch中对应的商品数据
            itemDao.delete(id.toString());
            // 下架成功后，删除Redis中的缓存数据
            redisDao.delete(itemKeyPrefix+id);
            redisDao.delete(itemDescKeyPrefix+id);
            redisDao.delete(itemParamItemKeyPrefix+id);

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("下架商品时数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 在商业代码的服务逻辑中。每个方法都是和具体的服务（功能）对应的。
     * 即使代码可重用，也必须定义不同的服务接口方法。可以在实现类型中找重用方式。
     * 上架商品
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult onshelfItemById(Long id) {
        // 上架
        try {
            int rows = updateItemStatus(id, 1);
            if (rows != 1) {
                throw new DaoException("上架商品错误");
            }

            TbItem tbItem = itemMapper.selectById(id);
            String categoryName =
                    itemCatMapper.selectById(tbItem.getCid()).getName();
            String itemDesc =
                    itemDescMapper.selectById(tbItem.getId()).getItemDesc();

            // 数据新增到数据库MySQL后，同步到Elasticsearch中。
            Item item = new Item();
            item.setId(tbItem.getId().toString());
            item.setTitle(tbItem.getTitle());
            item.setImage(tbItem.getImage());
            item.setItemDesc(itemDesc);
            item.setPrice(tbItem.getPrice());
            item.setSellPoint(tbItem.getSellPoint());
            item.setCategoryName(categoryName);
            item.setUpdated(tbItem.getUpdated());

            // 保存Item到Elasticsearch
            itemDao.save(item);

            // 保存商品相关数据到Redis，新增缓存或覆盖缓存
            redisDao.set(itemKeyPrefix+id,
                    itemMapper.selectById(id),
                    7L, TimeUnit.DAYS);
            redisDao.set(itemDescKeyPrefix+id,
                    itemDescMapper.selectById(id),
                    7L, TimeUnit.DAYS);
            redisDao.set(itemParamItemKeyPrefix+id,
                    itemParamItemMapper.selectOne(
                            new QueryWrapper<TbItemParamItem>()
                                    .eq("item_id", id)),
                    7L, TimeUnit.DAYS);

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("上架商品时数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 标记删除商品
     * MyBatisPlus中，有方法updateXxx。更新方法。
     * 底层代码自动判断，要更新的数据对象属性值不是null，更新对应字段值。属性值是null，则不更新。
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult dropItemById(Long id) {
        // 删除
        try {
            int rows = updateItemStatus(id, 3);
            if (rows != 1) {
                throw new DaoException("删除商品错误");
            }

            // 删除成功后，删除Elasticsearch中对应的商品数据
            itemDao.delete(id.toString());
            // 删除Redis中的商品缓存数据
            redisDao.delete(itemKeyPrefix+id);
            redisDao.delete(itemDescKeyPrefix+id);
            redisDao.delete(itemParamItemKeyPrefix+id);

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("删除商品时数据库访问错误：" + e.getMessage());
        }
        /*TbItem item = new TbItem();
        item.setId(id);
        item.setStatus(3);
        item.setUpdated(new Date());
        try {
            int rows = itemMapper.updateById(item);
            if (rows != 1) {
                throw new DaoException("删除商品错误");
            }
            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("删除商品时数据库访问错误：" + e.getMessage());
        }*/
    }

    /**
     * 更新商品状态，用于封装通用逻辑
     * @return
     */
    private int updateItemStatus(Long id, Integer status){
        TbItem item = new TbItem();
        item.setId(id);
        item.setStatus(status);
        item.setUpdated(new Date());
        return  itemMapper.updateById(item);
    }

    /**
     * 新增商品
     * @param tbItem 新增的商品
     * @param tbItemDesc 新增商品的图文介绍
     * @param tbItemParamItem 新增商品的具体规格
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult createItem(TbItem tbItem, TbItemDesc tbItemDesc, TbItemParamItem tbItemParamItem) {
        // 把要新增的数据中缺少的字段值补充完整。数据完整性处理。
        Date now = new Date();
        Long itemId = IDUtils.genItemId();
        tbItem.setId(itemId); // 商品主键
        tbItem.setStatus(1); // 商品状态，1是在售正常状态
        tbItem.setCreated(now); // 创建时间
        tbItem.setUpdated(now); // 更新时间

        tbItemDesc.setItemId(itemId);
        tbItemDesc.setCreated(now);

        tbItemParamItem.setId(IDUtils.genItemId());
        tbItemParamItem.setItemId(itemId);
        tbItemParamItem.setCreated(now);
        try {

            // 新增商品
            int rows = itemMapper.insert(tbItem);
            if (rows != 1) {
                throw new DaoException("新增商品错误 - 新增商品到tb_item表格错误");
            }
            // 新增商品图文介绍
            rows = itemDescMapper.insert(tbItemDesc);
            if (rows != 1) {
                throw new DaoException("新增商品错误 - 新增商品图文介绍到tb_item_desc表格错误");
            }

            // 新增商品具体规格
            rows = itemParamItemMapper.insert(tbItemParamItem);
            if (rows != 1) {
                throw new DaoException("新增商品错误 - 新增商品具体规格到tb_item_param_item表格错误");
            }

            // 数据新增到数据库MySQL后，同步到Elasticsearch中。
            Item item = new Item();
            item.setId(tbItem.getId().toString());
            item.setTitle(tbItem.getTitle());
            item.setImage(tbItem.getImage());
            item.setItemDesc(tbItemDesc.getItemDesc());
            item.setPrice(tbItem.getPrice());
            item.setSellPoint(tbItem.getSellPoint());
            item.setCategoryName(
                    itemCatMapper.selectById(tbItem.getCid()).getName()
            );
            item.setUpdated(tbItem.getUpdated());

            // 保存Item到Elasticsearch
            itemDao.save(item);

            // 保存商品相关数据到Redis，新增缓存或覆盖缓存
            redisDao.set(itemKeyPrefix+tbItem.getId(),
                    itemMapper.selectById(tbItem.getId()),
                    7L, TimeUnit.DAYS);
            redisDao.set(itemDescKeyPrefix+tbItem.getId(),
                    itemDescMapper.selectById(tbItem.getId()),
                    7L, TimeUnit.DAYS);
            redisDao.set(itemParamItemKeyPrefix+tbItem.getId(),
                    itemParamItemMapper.selectOne(
                            new QueryWrapper<TbItemParamItem>()
                                    .eq("item_id", tbItem.getId())),
                    7L, TimeUnit.DAYS);

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            e.printStackTrace();
            throw new DaoException("新增商品错误，MyBatisPlus访问数据库错误：" + e.getMessage());
        }
    }

    /**
     * 分页查询商品。
     * 表格是tb_item
     *
     * 分页查询方法
     * <T extends IPage> T selectPage(T page, QueryWrapper query)
     * IPage - 是MyBatisPlush定义的一个分页条件接口。
     *  有若干方法，可以获取查询的当前页数据集合，总计数据行数等。
     *
     * @param page
     * @param rows
     * @return
     */
    @Override
    public BaizhanResult getItemsByPage(int page, int rows) {
        // Page<>(int 查第几页, int 每页多少数据)
        IPage<TbItem> iPage = new Page<>(page, rows);
        IPage<TbItem> resultPage = itemMapper.selectPage(iPage, new QueryWrapper<>());
        // 总计数据行数
        long total = resultPage.getTotal();
        // 当前页数据集合
        List<TbItem> list = resultPage.getRecords();
        Map<String, Object> data = new HashMap<>();
        data.put("total", total);
        data.put("result", list);

        return BaizhanResult.ok(data);
    }
}
