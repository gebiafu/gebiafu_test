package com.bjsxt.itemcat.service;

import com.bjsxt.commons.pojo.BaizhanResult;

/**
 * 后台商品类型 - 服务接口
 */
public interface ItemCategoryService {
    /**
     * 根据父类型主键，查询子类型集合
     * @param id
     * @return
     */
    BaizhanResult getItemCatsByParentId(Long id);
}
