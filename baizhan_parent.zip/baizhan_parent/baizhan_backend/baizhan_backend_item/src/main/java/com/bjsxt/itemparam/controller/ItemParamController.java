package com.bjsxt.itemparam.controller;

import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.itemparam.service.ItemParamService;
import com.bjsxt.pojo.TbItemParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 后台商品系统，商品规格控制器
 */
@RestController
@Slf4j
public class ItemParamController {
    @Autowired
    private ItemParamService itemParamService;

    /**
     * 根据商品分类主键，查询规格
     * @param itemCatId
     * @return
     */
    @GetMapping("/backend/itemParam/selectItemParamByItemCatId/{itemCatId}")
    public BaizhanResult getItemParamByItemCategory(@PathVariable("itemCatId") Long itemCatId){
        return itemParamService.getItemParamByItemCategoryId(itemCatId);
    }

    /**
     * 根据主键，删除规格
     * @param id
     * @return
     */
    @GetMapping("/backend/itemParam/deleteItemParamById")
    public BaizhanResult removeItemParamById(Long id){
        return itemParamService.removeItemParamById(id);
    }

    /**
     * 创建新商品规格
     * @return
     */
    @PostMapping("/backend/itemParam/insertItemParam")
    public BaizhanResult createItemParam(TbItemParam itemParam){
        try {
            log.info("后台商品系统 - 商品规格管理 - 新增商品规格");
            return itemParamService.createItemParam(itemParam);
        }catch (DaoException e){
            log.error("后台商品系统 - 商品规格管理 - 新增商品规格异常 - " + e.getMessage());
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 根据商品分类的主键，判断分类是否有对应的规格数据
     * @return
     */
    @GetMapping("/backend/itemParam/selectHaveParam")
    public BaizhanResult getHasItemParamByItemCatId(Long itemCatId){
        log.info("后台商品系统 - 商品规格管理 - 判断分类是否有对应的规格数据");
        return itemParamService.getHasItemParamByItemCatId(itemCatId);
    }

    /**
     * 规格参数查询, get请求，不分页。查询全部
     */
    @GetMapping("/backend/itemParam/selectItemParamAll")
    public BaizhanResult getItemParamAll(){
        return itemParamService.getItemParamAll();
    }
}
