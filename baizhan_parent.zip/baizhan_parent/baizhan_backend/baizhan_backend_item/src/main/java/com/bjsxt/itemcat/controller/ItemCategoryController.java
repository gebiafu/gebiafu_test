package com.bjsxt.itemcat.controller;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.itemcat.service.ItemCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 后台商品管理 - 商品类型控制器
 */
@RestController
public class ItemCategoryController {
    @Autowired
    private ItemCategoryService itemCategoryService;

    /**
     * 根据父类型主键，查询子类型集合。
     * @param id 父类型主键,有默认值，0。
     * @return
     */
    @PostMapping("/backend/itemCategory/selectItemCategoryByParentId")
    public BaizhanResult getItemCatsByParentId(@RequestParam(defaultValue = "0") Long id){
        return itemCategoryService.getItemCatsByParentId(id);
    }
}
