package com.bjsxt.itemcat.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.itemcat.service.ItemCategoryService;
import com.bjsxt.itemcat.vo.ItemCategory;
import com.bjsxt.mapper.TbItemCatMapper;
import com.bjsxt.pojo.TbItemCat;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 后台商品类型 - 服务实现
 */
@Service
public class ItemCategoryServiceImpl implements ItemCategoryService {
    @Autowired
    private TbItemCatMapper itemCatMapper;

    /**
     * 查询表格tb_item_cat数据。
     * MyBatisPlus条件查询方式：
     *  根据某条件，查询若干条数据
     *  List<具体的实体类型> selectList(QueryWrapper<具体的实体类型> 查询条件)
     *  QueryWrapper提供了构造方法，可以创建查询条件对象。
     *  QueryWrapper类型中，提供若干方法，用于设置查询条件。
     *  各方法命名和具体条件相关。
     *  如：等值查询  eq()
     *  如：不等值查询  ne()
     *  如：大于   gt()
     *  如：大于等于   ge()
     *  并且提供了逻辑符号方法。
     *  如：and逻辑  and()
     *  如： or逻辑  or()
     * @param id
     * @return
     */
    @Override
    public BaizhanResult getItemCatsByParentId(Long id) {
        QueryWrapper<TbItemCat> queryWrapper =
                new QueryWrapper<>();
        // 传入字段名，不是Java实体类型中的属性名。
        queryWrapper.eq("parent_id", id);

        // 根据条件查询若干数据
        List<TbItemCat> list = itemCatMapper.selectList(queryWrapper);

        // 转换查询结果TbItemCat对象 -> ItemCategory对象。
        List<ItemCategory> resultList = new ArrayList<>(list.size());
        for(TbItemCat itemCat : list){
            // 拿到一个TbItemCat类型对象。
            // 创建一个ItemCategory类型对象。
            ItemCategory itemCategory = new ItemCategory();
            // 把TbItemCat类型对象的属性，同名赋值给ItemCategory类型的对象。
            //itemCategory.setId(itemCat.getId());
            // Spring Beans中提供的工具类型。copyProperties是同名复制属性值。
            // 是根据Property复制，不是根据Field复制。
            // 依据是Property类型和名称完全一致。自动复制。

            BeanUtils.copyProperties(itemCat, itemCategory);
            resultList.add(itemCategory);
        }

        return BaizhanResult.ok(resultList);
    }
}
