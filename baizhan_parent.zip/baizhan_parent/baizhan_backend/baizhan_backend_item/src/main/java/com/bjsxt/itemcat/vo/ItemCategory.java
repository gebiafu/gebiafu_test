package com.bjsxt.itemcat.vo;

import com.bjsxt.pojo.TbItemCat;

/**
 * 值对象。于实体类型的区别是：不会做持久化处理。绝对不保存到数据库中。
 * 只在项目的各层次代码中传递。
 * 如：控制器和服务代码间传递。控制器和页面传递。前端和后端传递。
 * jackson处理Java对象和JSON格式字符串转换的时候，要求每个属性必须有成对的getter和setter
 *  （除getClass以外）
 */
public class ItemCategory extends TbItemCat {
    public boolean getLeaf(){
        return !getIsParent();
    }
    public void setLeaf(boolean leaf){
        setIsParent(!leaf);
    }
}
