package com.bjsxt.item.controller;

import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.item.service.ItemService;
import com.bjsxt.pojo.TbItem;
import com.bjsxt.pojo.TbItemDesc;
import com.bjsxt.pojo.TbItemParamItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 后台商品控制器
 */
@RestController
public class ItemController {
    @Autowired
    private ItemService itemService;

    /**
     * 创建订单时，修改商品库存
     * @param params 要修改的商品库存数据
     *               key            value
     *               商品主键       购买数量
     * @return
     */
    @PostMapping("/backend/item/modifyItemNum4CreateOrder")
    public BaizhanResult modifyItemNum4CreateOrder(@RequestBody Map<Long, Integer> params){
        return itemService.modifyItemNum4CreateOrder(params);
    }

    /**
     * 查询商品相关数据，为Elasticsearch初始化数据提供服务
     */
    @PostMapping("/backend/item/getItems4InitElasticsearch")
    public BaizhanResult getItems4InitElasticsearch(){
        return itemService.getItems4InitElasticsearch();
    }

    /**
     * 更新商品数据
     * @return
     */
    @PostMapping("/backend/item/updateTbItem")
    public BaizhanResult modifyItem(TbItem item,
                                    TbItemDesc itemDesc,
                                    TbItemParamItem itemParamItem){
        try{
            return itemService.modifyItem(item, itemDesc, itemParamItem);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 更新商品前的查询逻辑。预更新
     * @return
     */
    @PostMapping("/backend/item/preUpdateItem")
    public BaizhanResult getItemPreModify(Long id){
        return itemService.getItemPreModify(id);
    }

    /**
     * 下架商品，更新状态为2
     * @param id
     * @return
     */
    @PostMapping("/backend/item/offshelfItemById")
    public BaizhanResult offshelfItemById(Long id){
        try{
            return itemService.offshelfItemById(id);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 上架商品，即更新商品状态字段为1。
     * @param id
     * @return
     */
    @PostMapping("/backend/item/onshelfItemById")
    public BaizhanResult onshelfItemById(Long id){
        try{
            return itemService.onshelfItemById(id);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 根据主键删除商品。标记删除。即更新状态。
     * @param id
     * @return
     */
    @PostMapping("/backend/item/deleteItemById")
    public BaizhanResult dropItemById(Long id){
        try{
            return itemService.dropItemById(id);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 新增商品
     * @param tbItem 新增的商品
     * @param tbItemDesc 新增商品的图文介绍
     * @param tbItemParamItem 新增商品的具体规格
     * @return
     */
    @PostMapping("/backend/item/insertTbItem")
    public BaizhanResult createItem(TbItem tbItem,
                                    TbItemDesc tbItemDesc,
                                    TbItemParamItem tbItemParamItem){
        try {
            return itemService.createItem(tbItem, tbItemDesc, tbItemParamItem);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 分页查询商品
     * @param page
     * @param rows
     * @return
     */
    @GetMapping("/backend/item/selectTbItemAllByPage")
    public BaizhanResult getItemsByPage(@RequestParam(defaultValue = "1") int page,
                                        @RequestParam(defaultValue = "10") int rows){
        return itemService.getItemsByPage(page, rows);
    }
}
