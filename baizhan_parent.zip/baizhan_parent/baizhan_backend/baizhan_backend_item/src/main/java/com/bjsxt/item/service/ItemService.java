package com.bjsxt.item.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbItem;
import com.bjsxt.pojo.TbItemDesc;
import com.bjsxt.pojo.TbItemParamItem;

import java.util.Map;

/**
 * 后台商品服务接口
 */
public interface ItemService {
    /**
     * 创建订单时，修改商品库存
     * @param params
     * @return
     */
    BaizhanResult modifyItemNum4CreateOrder(Map<Long, Integer> params);

    /**
     * 为Elasticsearch初始化查询商品相关数据。
     * @return
     */
    BaizhanResult getItems4InitElasticsearch();

    /**
     * 上架商品，即更新商品状态字段为1。
     * @param id
     * @return
     */
    BaizhanResult onshelfItemById(Long id);

    /**
     * 下架商品
     * @param id
     * @return
     */
    BaizhanResult offshelfItemById(Long id);

    /**
     * 根据主键删除商品。标记删除。即更新状态。
     * @param id
     * @return
     */
    BaizhanResult dropItemById(Long id);

    /**
     * 新增商品
     * @param tbItem 新增的商品
     * @param tbItemDesc 新增商品的图文介绍
     * @param tbItemParamItem 新增商品的具体规格
     * @return
     */
    BaizhanResult createItem(TbItem tbItem, TbItemDesc tbItemDesc,
                             TbItemParamItem tbItemParamItem);

    /**
     * 分页查询商品
     * @param page
     * @param rows
     * @return
     */
    BaizhanResult getItemsByPage(int page, int rows);

    /**
     * 预更新
     * @param id
     * @return
     */
    BaizhanResult getItemPreModify(Long id);

    /**
     * 更新商品
     * @param item
     * @param itemDesc
     * @param itemParamItem
     * @return
     */
    BaizhanResult modifyItem(TbItem item, TbItemDesc itemDesc, TbItemParamItem itemParamItem);
}
