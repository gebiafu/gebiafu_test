package com.bjsxt.item.dao;

import com.bjsxt.item.pojo.Item;

/**
 * 商品数据访问接口。处理后台商品管理过程中，同步Elasticsearch数据
 */
public interface ItemDao {
    /**
     * 保存商品到Elasticsearch
     * 主键不存在是新增，主键存在是覆盖
     * @param item
     */
    void save(Item item);

    /**
     * 根据主键删除Elasticsearch中的数据
     * @param id
     */
    void delete(String id);
}
