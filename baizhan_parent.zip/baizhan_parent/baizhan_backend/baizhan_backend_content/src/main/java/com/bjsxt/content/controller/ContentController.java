package com.bjsxt.content.controller;

import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.content.service.ContentService;
import com.bjsxt.pojo.TbContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 后台 内容 控制器
 */
@RestController
public class ContentController {
    @Autowired
    private ContentService contentService;

    /**
     * 根据主键删除内容
     * @param id
     * @return
     */
    @PostMapping("/backend/content/deleteContentByIds")
    public BaizhanResult removeContentById(Long id){
        try{
            return contentService.removeContentById(id);
        }catch (DaoException e){
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 创建内容
     * 商业项目至少有额外的2个字段，生效时间和失效时间。在查询的时候，要求
     *   生效时间 < 系统当前时间 < 失效时间
     * 选择性增加其他字段， 如：推荐、内部、级别
     * @param content
     * @return
     */
    @PostMapping("/backend/content/insertTbContent")
    public BaizhanResult createContent(TbContent content){
        try{
            return contentService.createContent(content);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 根据内容分类主键，查询内容数据集合。无分页处理。
     * 商业项目，一定有分页。
     * @param categoryId
     * @return
     */
    @PostMapping("/backend/content/selectTbContentAllByCategoryId")
    public BaizhanResult getContentByCategoryId(Long categoryId){
        return contentService.getContentByCategoryId(categoryId);
    }
}
