package com.bjsxt.contentcategory.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.contentcategory.service.ContentCategoryService;
import com.bjsxt.contentcategory.vo.ContentCategory;
import com.bjsxt.mapper.TbContentCategoryMapper;
import com.bjsxt.pojo.TbContentCategory;
import com.bjsxt.utils.IDUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 后台 内容分类 服务实现
 */
@Service
public class ContentCategoryServiceImpl implements ContentCategoryService {
    @Autowired
    private TbContentCategoryMapper contentCategoryMapper;

    /**
     * 修改内容分类
     * 注意： 修改后的内容分类名称，不能有同层次同名的正常内容分类。
     * @param contentCategory
     * @return
     */
    @Override
    @Transactional
    public BaizhanResult modifyContentCategory(TbContentCategory contentCategory) {
        try {
            // 查询当前要修改内容分类原始数据
            TbContentCategory oldContentCategory =
                    contentCategoryMapper.selectById(contentCategory.getId());
            // 查询同层次，同命名，的正常内容分类数量
            QueryWrapper<TbContentCategory> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("parent_id", oldContentCategory.getParentId())
                    .eq("name", contentCategory.getName())
                    .eq("status", 1);
            Integer rows = contentCategoryMapper.selectCount(queryWrapper);
            if (rows != null && rows > 0) {
                // 有同名的，同层次的，正常状态的其他内容分类
                return BaizhanResult.error("内容分类名称相同，请重新编辑");
            }
            // 更新数据
            contentCategory.setUpdated(new Date());
            rows = contentCategoryMapper.updateById(contentCategory);
            if (rows != 1) {
                throw new DaoException("更新内容分类错误");
            }
            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("更新内容分类时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 删除内容分类
     *  标记删除。设置状态status = 2。
     * 分析： 删除父内容分类的时候，如何处理子内容分类？
     *  当前系统使用递归处理，删除父内容分类，递归删除所有的子内容分类。
     * 注意：删除结束后，一定要检查，当前内容分类的父内容分类，是否还有其他正常状态的
     *      子内容分类，如果没有，则修改is_parent字段为false。
     * @param id
     * @return
     */
    @Override
    @Transactional
    public BaizhanResult removeContentCategory(Long id) {
        try {
            // 查询当前要删除的内容分类数据, 为后续的父节点相关处理准备基础数据。
            TbContentCategory current =
                    contentCategoryMapper.selectById(id);
            // 递归删除要删除的内容分类
            Date update = new Date();
            removeCurrentAndChildren(current.getId(), update);

            // 删除成功
            // 判断父内容分类是否有其他的正常状态子内容分类
            QueryWrapper<TbContentCategory> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("parent_id", current.getParentId())
                    .eq("status", 1);
            List<TbContentCategory> siblings =
                    contentCategoryMapper.selectList(queryWrapper);

            if (siblings.size() == 0) {
                // 没有正常状态的子节点集合，更新isParent=false
                TbContentCategory parent = new TbContentCategory();
                parent.setId(current.getParentId());
                parent.setIsParent(false);
                parent.setUpdated(update);
                int rows =
                        contentCategoryMapper.updateById(parent);
                if (rows != 1) {
                    throw new DaoException("删除内容分类时，更新父内容分类isParent错误");
                }
            }
            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("删除内容分类时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 递归删除方法。
     * @param currentId 要递归删除的当前内容分类主键
     * @param updated 删除时间
     */
    private void removeCurrentAndChildren(Long currentId, Date updated){
        // 查询当前要删除的内容分类对象，判断是否还有正常状态的子内容分类
        TbContentCategory current =
                contentCategoryMapper.selectById(currentId);
        if(current.getIsParent()){
            // 当前要删除的内容分类是父内容分类，一定有子内容分类。开始查询
            QueryWrapper<TbContentCategory> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("parent_id", currentId)
                    .eq("status", 1);
            List<TbContentCategory> children =
                    contentCategoryMapper.selectList(queryWrapper);
            // 循环删除每个子节点，使用递归逻辑实现
            for(TbContentCategory child : children){
                removeCurrentAndChildren(child.getId(), updated);
            }
        }

        // 无论当前内容分类是否有子内容分类，当前内容分类都要删除处理
        current.setStatus(2);
        current.setUpdated(updated);

        int rows = contentCategoryMapper.updateById(current);
        if(rows != 1){
            throw new DaoException("递归删除内容分类错误");
        }
    }

    /**
     * 新增内容分类
     * 新增要求：
     *  新增的内容分类，没有同名的同层次正常状态分类。
     *  相同父内容分类的正常状态的 分类名称， 不能相同。
     * @param contentCategory
     * @return
     */
    @Override
    @Transactional(rollbackFor = {DaoException.class})
    public BaizhanResult createContentCategory(TbContentCategory contentCategory) {
        try {
            // 校验新增的内容分类名称是否可用
            QueryWrapper<TbContentCategory> queryWrapper =
                    new QueryWrapper<>();
            queryWrapper.eq("parent_id", contentCategory.getParentId())
                    .eq("status", 1)
                    .eq("name", contentCategory.getName());
            // 统计查询，查询复合条件的数据行数
            Integer rows = contentCategory.selectCount(queryWrapper);
            if (rows != null && rows > 0) {
                // 有同名的内容分类，不能新增
                return BaizhanResult.error("新增内容分类 '" + contentCategory.getName() +
                        "' 有同名其他分类，请重新编辑");
            }

            // 数据完整性
            contentCategory.setId(IDUtils.genItemId());
            contentCategory.setStatus(1); // 正常状态
            contentCategory.setSortOrder(1); // 默认排列顺序 1
            contentCategory.setCreated(new Date()); // 创建时间
            contentCategory.setIsParent(false); // 设置是否是父节点，数据库默认true。
            contentCategory.setUpdated(contentCategory.getCreated()); // 新增时更新和创建时间等同

            // 新增数据到数据库。
            rows = contentCategoryMapper.insert(contentCategory);
            if (rows != 1) {
                // 新增错误
                throw new DaoException("新增内容分类错误");
            }

            // 修改父内容分类的is_parent字段为1。表示父内容分类一定是一个父节点。
            TbContentCategory parentCategory =
                    new TbContentCategory();
            parentCategory.setId(contentCategory.getParentId());
            parentCategory.setIsParent(true);
            parentCategory.setUpdated(contentCategory.getUpdated());
            rows = contentCategoryMapper.updateById(parentCategory);
            if(rows != 1){
                throw new DaoException("新增内容分类时，更新父内容分类isParent属性错误");
            }

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("新增内容分类时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 根据父内容分类主键，查询子内容分类集合
     * 查询数据来源是： tb_content_category表格。
     * 查询条件： 父内容分类 parent_id = 方法参数 id
     *           状态 status = 正常状态 1
     * 排序条件： 先按照sort_order自然升序排列，同值按照内容分类名称name自然升序怕排列
     * @param id
     * @return
     */
    @Override
    public BaizhanResult getContentCategoryByParent(Long id) {
        QueryWrapper<TbContentCategory> queryWrapper =
                new QueryWrapper<>();
        // 默认就是and并列条件
        queryWrapper.eq("parent_id", id)
                .eq("status", 1);
        // 增加排序逻辑
        // sort_order自然升序，同值，name自然升序
        // queryWrapper.orderByAsc("sort_order", "name");
        // sort_order自然降序，同值， name自然升序
        queryWrapper.orderByDesc("sort_order").orderByAsc("name");

        // 查询
        List<TbContentCategory> list =
                contentCategoryMapper.selectList(queryWrapper);

        // 处理返回结果
        List<ContentCategory> resultList =
                new ArrayList<>(list.size());
        for(TbContentCategory contentCategory : list){
            ContentCategory category = new ContentCategory();
            BeanUtils.copyProperties(contentCategory, category);
            resultList.add(category);
        }

        return BaizhanResult.ok(resultList);
    }
}
