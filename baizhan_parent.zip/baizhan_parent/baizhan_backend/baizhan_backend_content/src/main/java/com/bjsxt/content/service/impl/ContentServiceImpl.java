package com.bjsxt.content.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.content.service.ContentService;
import com.bjsxt.mapper.TbContentMapper;
import com.bjsxt.pojo.TbContent;
import com.bjsxt.utils.IDUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * 后台 内容 服务实现
 */
@Service
public class ContentServiceImpl implements ContentService {
    @Autowired
    private TbContentMapper contentMapper;

    /**
     * 根据主键删除内容
     * @param id
     * @return
     */
    @Override
    @Transactional
    @CacheEvict(cacheNames = "baizhan:portal:bigAd", key = "'getAllBigAd'")
    public BaizhanResult removeContentById(Long id) {
        try {
            int rows = contentMapper.deleteById(id);
            if (rows != 1) {
                throw new DaoException("删除内容错误");
            }
            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("删除内容时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 新增内容
     * @param content
     * @return
     */
    @Override
    @Transactional
    @CacheEvict(cacheNames = "baizhan:portal:bigAd", key = "'getAllBigAd'")
    public BaizhanResult createContent(TbContent content) {
        try {
            // 完整性处理
            content.setId(IDUtils.genItemId());
            Date now = new Date();
            content.setCreated(now);
            content.setUpdated(now);

            // 新增数据到数据库
            int rows = contentMapper.insert(content);
            if (rows != 1) {
                throw new DaoException("新增内容到数据库错误");
            }

            return BaizhanResult.ok();
        }catch (DaoException e){
            throw e;
        }catch (Exception e){
            throw new DaoException("新增内容到数据库时，数据库访问错误：" + e.getMessage());
        }
    }

    /**
     * 根据内容分类主键，查询内容集合。
     * 访问tb_content表格
     * @param categoryId
     * @return
     */
    @Override
    public BaizhanResult getContentByCategoryId(Long categoryId) {
        QueryWrapper<TbContent> queryWrapper =
                new QueryWrapper<>();
        queryWrapper.eq("category_id", categoryId);
        // 按照创建时间倒序排列
        queryWrapper.orderByDesc("updated");

        List<TbContent> list = contentMapper.selectList(queryWrapper);

        return BaizhanResult.ok(list);
    }
}
