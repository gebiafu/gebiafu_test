package com.bjsxt.content.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbContent;

/**
 * 后台 内容 服务接口
 */
public interface ContentService {
    /**
     * 根据主键删除内容
     * @param id
     * @return
     */
    BaizhanResult removeContentById(Long id);

    /**
     * 新增内容
     * @param content
     * @return
     */
    BaizhanResult createContent(TbContent content);

    /**
     * 根据内容分类主键，查询内容集合
     * @param categoryId
     * @return
     */
    BaizhanResult getContentByCategoryId(Long categoryId);
}
