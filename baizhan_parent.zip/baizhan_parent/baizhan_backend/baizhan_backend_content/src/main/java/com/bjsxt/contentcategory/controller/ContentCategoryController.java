package com.bjsxt.contentcategory.controller;

import com.bjsxt.commons.exception.DaoException;
import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.contentcategory.service.ContentCategoryService;
import com.bjsxt.pojo.TbContentCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 后台 内容分类 控制器
 */
@RestController
public class ContentCategoryController {
    @Autowired
    private ContentCategoryService contentCategoryService;

    /**
     * 修改内容分类，就是修改内容分类名称
     * @param contentCategory
     * @return
     */
    @PostMapping("/backend/contentCategory/updateContentCategory")
    public BaizhanResult modifyContentCategory(TbContentCategory contentCategory){
        try{
            return contentCategoryService.modifyContentCategory(contentCategory);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 删除内容分类
     * @param id
     * @return
     */
    @PostMapping("/backend/contentCategory/deleteContentCategoryById")
    public BaizhanResult removeContentCategory(Long id){
        try {
            return contentCategoryService.removeContentCategory(id);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 新增内容分类
     * @param contentCategory 包括父内容分类主键，当前内容分类名称
     * @return
     */
    @PostMapping("/backend/contentCategory/insertContentCategory")
    public BaizhanResult createContentCategory(TbContentCategory contentCategory){
        try{
            return contentCategoryService.createContentCategory(contentCategory);
        }catch (DaoException e){
            e.printStackTrace();
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }

    /**
     * 根据父内容分类主键，查询子内容分类集合
     * @param id
     * @return
     */
    @PostMapping("/backend/contentCategory/selectContentCategoryByParentId")
    public BaizhanResult getContentCategoryByParent(@RequestParam(defaultValue = "0") Long id){
        return contentCategoryService.getContentCategoryByParent(id);
    }
}
