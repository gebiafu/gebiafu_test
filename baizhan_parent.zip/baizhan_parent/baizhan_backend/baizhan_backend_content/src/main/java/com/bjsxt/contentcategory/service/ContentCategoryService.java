package com.bjsxt.contentcategory.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.pojo.TbContentCategory;

/**
 * 后台 内容分类 服务接口
 */

public interface ContentCategoryService {
    /**
     * 修改内容分类
     * @param contentCategory
     * @return
     */
    BaizhanResult modifyContentCategory(TbContentCategory contentCategory);

    /**
     * 删除内容分类
     * @param id
     * @return
     */
    BaizhanResult removeContentCategory(Long id);

    /**
     * 新增内容分类
     * @param contentCategory
     * @return
     */
    BaizhanResult createContentCategory(TbContentCategory contentCategory);

    /**
     * 根据父内容分类主键，查询子内容分类集合
     * @param id
     * @return
     */
    BaizhanResult getContentCategoryByParent(Long id);
}
