package com.bjsxt.contentcategory.vo;

import com.bjsxt.pojo.TbContentCategory;

public class ContentCategory extends TbContentCategory {
    public boolean getLeaf(){
        return !getIsParent();
    }
    public void setLeaf(boolean leaf){
        setIsParent(!leaf);
    }
}
