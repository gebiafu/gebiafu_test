package com.bjsxt.message.pojo;

import java.io.Serializable;

/**
 * 当前项目工程中，所有消息的接口标准类型。
 */
public interface IMessage extends Serializable {
}
