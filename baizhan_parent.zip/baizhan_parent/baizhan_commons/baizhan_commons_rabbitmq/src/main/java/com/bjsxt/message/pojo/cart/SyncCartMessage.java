package com.bjsxt.message.pojo.cart;

import com.bjsxt.message.pojo.IMessage;
import lombok.Data;

import java.util.List;

/**
 * 下订单后，同步购物车的消息类型
 */
@Data
public class SyncCartMessage implements IMessage {
    private Long userId; // 购买人主键
    private List<Long> itemIds; // 要从购物车中删除的商品主键集合
}
