package com.bjsxt.message.pojo.notice;

import com.bjsxt.message.pojo.IMessage;
import lombok.Data;

/**
 * 通知消息。用于处理邮件，短信等通知的消息类型
 * xxx:订单编号是 yyy 的订单已成功创建，请及时支付。
 */
@Data
public class OrderNoticeMessage implements IMessage {
    private String name; // 购买者名称
    private Long orderId; // 订单主键
    private String email; // 购买者邮箱
    private String phone; // 购买者电话
}
