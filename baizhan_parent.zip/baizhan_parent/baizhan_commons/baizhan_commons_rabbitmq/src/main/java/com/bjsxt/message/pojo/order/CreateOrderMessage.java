package com.bjsxt.message.pojo.order;

import com.bjsxt.message.pojo.IMessage;
import com.bjsxt.pojo.TbOrder;
import com.bjsxt.pojo.TbOrderItem;
import com.bjsxt.pojo.TbOrderShipping;
import lombok.Data;

import java.util.List;

/**
 * 创建订单的消息类型
 */
@Data
public class CreateOrderMessage implements IMessage {
    // 创建订单，就是新增订单、订单物流、订单项，修改商品库存。
    private TbOrder order; // 要新增的订单
    private TbOrderShipping orderShipping; // 要新增的订单物流
    private List<TbOrderItem> orderItems; // 要新增的订单项集合
    private int times = 1;
}
