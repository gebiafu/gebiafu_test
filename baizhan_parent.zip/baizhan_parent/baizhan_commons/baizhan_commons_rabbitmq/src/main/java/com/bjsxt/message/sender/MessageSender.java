package com.bjsxt.message.sender;

import com.bjsxt.message.pojo.IMessage;
import org.springframework.amqp.core.AmqpTemplate;

/**
 * 发送消息的工具类型。
 */
public class MessageSender {
    private AmqpTemplate amqpTemplate;

    /**
     * 发送消息
     * @param exchange 交换器名称
     * @param routingKey 路由键
     * @param messageBody 消息内容
     * @return
     */
    public void sendMessage(String exchange, String routingKey, IMessage messageBody){
        amqpTemplate.convertAndSend(exchange, routingKey, messageBody);
    }

    public AmqpTemplate getAmqpTemplate() {
        return amqpTemplate;
    }

    public void setAmqpTemplate(AmqpTemplate amqpTemplate) {
        this.amqpTemplate = amqpTemplate;
    }
}
