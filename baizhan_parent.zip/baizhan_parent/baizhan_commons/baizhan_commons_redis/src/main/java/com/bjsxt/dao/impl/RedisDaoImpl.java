package com.bjsxt.dao.impl;

import com.bjsxt.dao.RedisDao;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;

public class RedisDaoImpl implements RedisDao {
    private RedisTemplate<String, Object> redisTemplate;

    @Override
    public void persist(String key) {
        redisTemplate.persist(key);
    }

    @Override
    public long getExpire(String key) {
        return redisTemplate.getExpire(key);
    }

    @Override
    public void setExpire(String key, long times) {
        redisTemplate.expire(key, times, TimeUnit.SECONDS);
    }

    @Override
    public <T> T get(String key) {
        return (T) redisTemplate.opsForValue().get(key);
    }

    @Override
    public void delete(String key) {
        redisTemplate.delete(key);
    }

    @Override
    public boolean setNx(String key, Object value) {
        return redisTemplate.opsForValue().setIfAbsent(key, value);
    }

    @Override
    public boolean setNx(String key, Object value, long times, TimeUnit unit) {
        return redisTemplate.opsForValue().setIfAbsent(key, value, times, unit);
    }

    @Override
    public void set(String key, Object value) {
        redisTemplate.opsForValue().set(key, value);
    }

    @Override
    public void set(String key, Object value, long times, TimeUnit unit) {
        redisTemplate.opsForValue().set(key, value, times, unit);
    }

    public RedisTemplate<String, Object> getRedisTemplate() {
        return redisTemplate;
    }

    public void setRedisTemplate(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }
}
