package com.bjsxt.config;

import com.bjsxt.dao.RedisDao;
import com.bjsxt.dao.impl.RedisDaoImpl;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * 定义抽象类型，提供RedisTemplate和RedisDao对象的创建通用规则
 * 如果使用当前代码的项目，需要默认的创建规则，集成并调用方法即可。
 * 如果需要特定的规则，自定义创建Bean对象的逻辑即可。
 */
public abstract class AbstractRedisConfiguration {
    /**
     * 通用创建RedisDao对象的方法
     * @param redisTemplate
     * @return
     */
    protected RedisDao redisDao(RedisTemplate<String, Object> redisTemplate){
        RedisDaoImpl redisDao = new RedisDaoImpl();
        redisDao.setRedisTemplate(redisTemplate);
        return redisDao;
    }

    /**
     * 通用创建RedisTemplate对象的方法。
     * @param factory
     * @return
     */
    protected RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory){
        RedisTemplate<String, Object> redisTemplate =
                new RedisTemplate<>();
        // 连接工厂
        redisTemplate.setConnectionFactory(factory);
        // key的序列化器。字符串序列化
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        // value的序列化器，JSON序列化
        redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        // hash数据类型的field序列化器。字符串序列化
        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        // hash数据类型的value序列化器，JSON序列化
        redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());

        return redisTemplate;
    }
}
