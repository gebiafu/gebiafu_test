package com.bjsxt.dao;

import java.util.concurrent.TimeUnit;

/**
 * 定义公共的Redis数据库访问接口
 */
public interface RedisDao {
    /**
     * 根据key，删除键值对的有效时长
     * @param key
     */
    void persist(String key);

    /**
     * 根据key，查询键值对剩余有效时长，单位是秒
     * @param key
     * @return
     */
    long getExpire(String key);

    /**
     * 设置键值对有效时长
     * @param key
     * @param times  时间 单位是秒
     */
    void setExpire(String key, long times);

    /**
     * 根据key查询value。
     * @param key
     * @param <T>
     * @return
     */
    <T> T get(String key);

    /**
     * 根据key删除键值对
     * @param key
     */
    void delete(String key);

    /**
     * 强制新增，key存在则不新增，不覆盖
     * @param key
     * @param value
     * @return 新增成功返回true。失败返回false
     */
    boolean setNx(String key, Object value);

    /**
     * 强制新增，key存在则不新增，不覆盖。新增成功的同时，设置有效时长
     * @param key
     * @param value
     * @param times 时间
     * @param unit 单位
     * @return
     */
    boolean setNx(String key, Object value, long times, TimeUnit unit);

    /**
     * 新增数据到Redis，覆盖同key的键值对
     * @param key
     * @param value
     */
    void set(String key, Object value);

    /**
     * 新增数据到Redis，覆盖同key的键值对。同时设置有效时长
     * @param key
     * @param value
     * @param times 时间
     * @param unit 单位
     */
    void set(String key, Object value, long times, TimeUnit unit);
}
