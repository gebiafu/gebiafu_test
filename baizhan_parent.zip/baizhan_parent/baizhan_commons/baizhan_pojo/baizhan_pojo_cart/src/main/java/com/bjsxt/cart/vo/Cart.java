package com.bjsxt.cart.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * 购物车类型。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cart implements Serializable {
    /**
     * 保存预计购买商品的集合。
     * key是商品的主键。
     * value是CartItem类型对象。
     */
    private Map<String, CartItem> carts = new HashMap<>();

    /**
     * 删除指定的键值对
     * @param itemId
     */
    public void removeItemFromCart(Long itemId){
        carts.remove(itemId.toString());
    }

    /**
     * 修改购物车商品数量
     * @param itemId
     * @param num
     */
    public void changeItemNum(Long itemId, int num){
        CartItem cartItem = carts.get(itemId.toString());
        if(cartItem == null){ // 可能发生的恶意访问。
            return ;
        }
        cartItem.setNum(num);
    }

    /**
     * 增加商品到购物车
     * @param cartItem
     */
    public void addCartItem2Cart(CartItem cartItem){
        carts.put(cartItem.getId().toString(), cartItem);
    }

    /**
     * 比较购物车中是否有主键相同的商品，如果有，则类型商品预计购买数量。
     * @param itemId
     * @param num
     * @return true - 有同主键商品，已累加数量； false - 没有同主键商品
     */
    public boolean containsCartItem(Long itemId, int num){
        // 查询商品
        CartItem cartItem = carts.get(itemId.toString());
        if(cartItem == null){
            // 购物车中没有同主键商品
            return false;
        }
        // 有相同主键商品，累加预计购买数量。
        cartItem.setNum(cartItem.getNum() + num);
        return true;
    }

    /**
     * 查询购物车中的所有商品数据
     * @return
     */
    public Collection<CartItem> showCart(){
        return carts.values();
    }
}
