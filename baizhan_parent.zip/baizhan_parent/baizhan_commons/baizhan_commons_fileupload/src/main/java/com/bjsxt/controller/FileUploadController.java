package com.bjsxt.controller;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class FileUploadController {
    @Autowired
    private FileUploadService fileUploadService;

    /**
     * 上传文件到FastDFS
     * @param file
     * @return
     */
    @PostMapping("/file/upload")
    public BaizhanResult fileUpload(MultipartFile file){
        return fileUploadService.fileUpload(file);
    }
}
