package com.bjsxt.service;

import com.bjsxt.commons.pojo.BaizhanResult;
import org.springframework.web.multipart.MultipartFile;

/**
 * 上传文件服务接口
 */
public interface FileUploadService {
    /**
     * 上传文件到FastDFS
     *
     * @param file
     * @return
     */
    BaizhanResult fileUpload(MultipartFile file);
}
