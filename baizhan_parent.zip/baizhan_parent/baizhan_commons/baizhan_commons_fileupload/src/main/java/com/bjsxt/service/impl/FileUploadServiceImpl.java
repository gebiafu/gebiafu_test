package com.bjsxt.service.impl;

import com.bjsxt.commons.pojo.BaizhanResult;
import com.bjsxt.service.FileUploadService;
import com.bjsxt.utils.FastDFSClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * 上传文件服务实现
 */
@Service
@Slf4j
public class FileUploadServiceImpl implements FileUploadService {

    @Value("${baizhan.fastdfs.nginx}")
    private String nginxServer;
    /**
     * 上传文件到FastDFS，基于FastDFS工具类型实现
     * @param file
     * @return
     */
    @Override
    public BaizhanResult fileUpload(MultipartFile file) {
        try {

            String[] result =
                    FastDFSClient.uploadFile(file.getInputStream(),
                            file.getOriginalFilename());

            if(null == result){
                // 上传文件到FastDFS失败
                log.error("上传文件错误，FastDFSClient工具类型代码错误");
                return BaizhanResult.error("服务器忙，请稍后重试");
            }

            return BaizhanResult.ok(nginxServer + result[0] + "/" + result[1]);
        }catch (Exception e){
            log.error("上传文件错误， 信息为：" + e.getMessage());
            return BaizhanResult.error("服务器忙，请稍后重试");
        }
    }
}
