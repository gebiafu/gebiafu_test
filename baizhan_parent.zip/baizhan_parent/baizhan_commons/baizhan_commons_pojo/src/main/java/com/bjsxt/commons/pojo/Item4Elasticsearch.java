package com.bjsxt.commons.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 定义用于查询传递Elasticsearch中需要的商品相关数据的实体。
 * 其中包括商品基本数据，商品分类数据，商品图文详情
 */
@Data
@NoArgsConstructor
public class Item4Elasticsearch implements Serializable {
    private String id; // 主键
    private String title; // 商品标题
    private String sellPoint; // 商品卖点
    private Long price; // 商品单价
    private String image; // 商品图片
    private String categoryName; // 商品分类名
    private String itemDesc; // 商品图文介绍
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updated; // 更新时间
}
